# ✅ First Steps Checklist

**Use this checklist to get AnnexFinder running today.**

## 🎯 Today (30 minutes)

### Step 1: Setup Environment (5 min)
```bash
cd annexfinder
chmod +x setup.sh
./setup.sh
```

- [ ] Database created (`annexfinder`)
- [ ] Schema loaded (15 tables created)
- [ ] Universities seeded (15 entries)
- [ ] Backend dependencies installed
- [ ] Frontend dependencies installed

**Verify:**
```bash
psql annexfinder -c "SELECT COUNT(*) FROM universities;"
# Should return: 15
```

### Step 2: Configure Backend (5 min)

Edit `backend/.env`:

- [ ] Set `DB_PASSWORD` (your PostgreSQL password)
- [ ] Set `JWT_SECRET` (long random string)
- [ ] Add PayHere credentials (get from payhere.lk)

**Minimum required:**
```bash
DB_HOST=localhost
DB_NAME=annexfinder
DB_USER=postgres
DB_PASSWORD=YOUR_PASSWORD
JWT_SECRET=your-long-random-secret-min-32-chars
```

### Step 3: Configure Frontend (2 min)

Edit `frontend/.env`:

- [ ] Set `NEXT_PUBLIC_API_URL=http://localhost:5000`

**That's all you need to start!**

### Step 4: Start Servers (3 min)

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
```
Wait for: ✓ Database connected successfully

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```
Wait for: ▲ Next.js ready

### Step 5: Test It Works (5 min)

- [ ] Open http://localhost:3000
- [ ] See beautiful home page
- [ ] Try dual-mode search toggle
- [ ] Check http://localhost:5000/health
- [ ] Should return `{"status":"ok"}`

**If you see the home page, you're done! ✅**

---

## 📅 This Week (Build Core Features)

### Day 1: Create Test Data

```bash
# Register an owner
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "owner@test.com",
    "password": "test1234",
    "name": "Test Owner",
    "role": "owner"
  }'
```

- [ ] Save the returned token
- [ ] Try login endpoint
- [ ] Create test property (see GETTING_STARTED.md)

### Day 2: Build Search Results Page

File: `frontend/app/search/page.tsx` (template already created!)

- [ ] Connect to `/api/search` endpoint
- [ ] Show PropertyCard components
- [ ] Add filter sidebar
- [ ] Integrate PropertyMap
- [ ] Test with real data

### Day 3: Build Property Detail Page

File: `frontend/app/property/[id]/page.tsx`

- [ ] Photo gallery component
- [ ] Property details display
- [ ] Distance map
- [ ] Enquiry form modal
- [ ] Similar properties section

### Day 4: Build Login/Register

Files: `frontend/app/login/page.tsx`, `frontend/app/register/page.tsx`

- [ ] Email + password form
- [ ] Role selection (tenant/owner)
- [ ] Store JWT token in localStorage
- [ ] Redirect after login
- [ ] Form validation

### Day 5: Build Owner Dashboard

File: `frontend/app/owner/dashboard/page.tsx`

- [ ] Metric cards (views, enquiries)
- [ ] Recent enquiries feed
- [ ] Listing status overview
- [ ] Connect to `/api/owner/stats`

---

## 🚀 Next Week (Polish & Launch Prep)

### Image Upload

- [ ] Install Multer: `npm install multer`
- [ ] Add Cloudinary config
- [ ] Implement upload endpoint
- [ ] Update listing form

### Email Notifications

- [ ] Get SendGrid API key
- [ ] Create email templates
- [ ] Implement new enquiry email
- [ ] Implement owner reply email

### Payment Testing

- [ ] Get PayHere sandbox credentials
- [ ] Test subscription purchase flow
- [ ] Verify webhook receives payment
- [ ] Check subscription activates

### Admin Panel

- [ ] Build listing review queue UI
- [ ] Approve/reject buttons
- [ ] Auto-scoring display
- [ ] User management page

---

## 📋 Pre-Launch Checklist

### Security

- [ ] Change JWT_SECRET to production secret
- [ ] Switch PayHere to live mode
- [ ] Enable HTTPS
- [ ] Review CORS settings
- [ ] Test webhook signature verification

### Features

- [ ] All core pages built
- [ ] Image upload working
- [ ] Email notifications sending
- [ ] Payment flow tested
- [ ] Admin panel functional

### Deployment

- [ ] Database on Railway/Supabase
- [ ] Backend on Railway/Render
- [ ] Frontend on Vercel
- [ ] Domain configured
- [ ] SSL certificates active

### Testing

- [ ] Register as tenant → search → enquire
- [ ] Register as owner → list → receive enquiry
- [ ] Purchase subscription → verify activation
- [ ] Admin approve/reject → verify emails
- [ ] Test on mobile devices

---

## 🎯 Quick Wins (Do These First!)

### 1. Add Your Logo (5 min)

Replace the "A" in `components/Navbar.tsx`:
```tsx
<img src="/logo.png" alt="AnnexFinder" className="w-10 h-10" />
```

### 2. Customize Colors (10 min)

Edit `frontend/tailwind.config.js`:
```javascript
ocean: { 500: '#YOUR_PRIMARY_COLOR' }
```

### 3. Add Real Universities (5 min)

Database already has 15. Add more in `database/schema.sql`:
```sql
INSERT INTO universities (name, city, lat, lng) VALUES
('Your University', 'City', 6.xxxx, 79.xxxx);
```

### 4. Test Spatial Search (2 min)

```bash
psql annexfinder

SELECT * FROM search_by_university('Colombo', 3000, 10);
```

Should return properties (empty at first, add test data).

---

## 🆘 Troubleshooting

### "Database connection refused"
```bash
sudo systemctl start postgresql
```

### "Module not found"
```bash
cd backend && npm install
cd frontend && npm install
```

### "PostGIS function not found"
```bash
psql annexfinder < database/queries.sql
```

### "Port 5000 already in use"
```bash
lsof -ti:5000 | xargs kill -9
```

---

## 📚 Resources

- **Full Setup**: See `GETTING_STARTED.md`
- **API Docs**: Check `backend/routes/*.js` (inline comments)
- **Deployment**: See `DEPLOYMENT.md`
- **Design System**: See `frontend/app/globals.css`

---

## ✅ Success Criteria

**Week 1 Goal:**
- [ ] Backend running locally
- [ ] Frontend showing home page
- [ ] Can create test property
- [ ] Can search for properties

**Week 2 Goal:**
- [ ] All main pages built
- [ ] User can register/login
- [ ] Enquiry system works
- [ ] Owner can list property

**Week 3 Goal:**
- [ ] Deployed to production
- [ ] Payment flow working
- [ ] Ready for beta users

---

**You've got this! 🚀**

Start with "Today" tasks. Once you see the home page, you're 90% there. The rest is just building pages using the components and API that already exist.

Questions? Every file has detailed comments. Start reading from `README.md`.
