@echo off
echo ========================================
echo   AnnexFinder Setup (Windows)
echo ========================================
echo.

REM Check Node.js
echo Checking Node.js...
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js not found!
    echo Download from: https://nodejs.org
    pause
    exit /b 1
)
echo OK: Node.js installed

REM Check PostgreSQL
echo Checking PostgreSQL...
psql --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: PostgreSQL not found!
    echo Download from: https://www.postgresql.org/download/windows/
    pause
    exit /b 1
)
echo OK: PostgreSQL installed

echo.
echo ========================================
echo   Setting up Database
echo ========================================
echo.

REM Create database
echo Creating database 'annexfinder'...
createdb annexfinder
if errorlevel 1 (
    echo Note: Database might already exist, continuing...
)

REM Load schema
echo Loading database schema...
psql annexfinder < database\schema.sql
if errorlevel 1 (
    echo ERROR: Failed to load schema!
    pause
    exit /b 1
)

REM Load queries
echo Loading spatial queries...
psql annexfinder < database\queries.sql
if errorlevel 1 (
    echo ERROR: Failed to load queries!
    pause
    exit /b 1
)

echo OK: Database setup complete

echo.
echo ========================================
echo   Installing Backend
echo ========================================
echo.

cd backend
echo Installing backend dependencies...
call npm install
if errorlevel 1 (
    echo ERROR: Backend installation failed!
    pause
    exit /b 1
)

REM Create .env file
if not exist .env (
    echo Creating .env file...
    copy ..\\.env.example .env
    echo.
    echo IMPORTANT: Edit backend\.env and add your:
    echo   - DB_PASSWORD
    echo   - JWT_SECRET
    echo.
)

cd ..

echo.
echo ========================================
echo   Installing Frontend
echo ========================================
echo.

cd frontend
echo Installing frontend dependencies...
call npm install
if errorlevel 1 (
    echo ERROR: Frontend installation failed!
    pause
    exit /b 1
)

REM Create .env file
if not exist .env (
    echo Creating .env file...
    copy ..\\.env.example .env
)

cd ..

echo.
echo ========================================
echo   Setup Complete!
echo ========================================
echo.
echo Next steps:
echo.
echo 1. Edit backend\.env:
echo    - Set DB_PASSWORD to your PostgreSQL password
echo    - Set JWT_SECRET to a long random string
echo.
echo 2. Start Backend (Terminal 1):
echo    cd backend
echo    npm run dev
echo.
echo 3. Start Frontend (Terminal 2):
echo    cd frontend
echo    npm run dev
echo.
echo 4. Open browser: http://localhost:3000
echo.
pause
