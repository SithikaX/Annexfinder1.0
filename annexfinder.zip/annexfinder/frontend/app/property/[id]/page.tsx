// app/property/[id]/page.tsx - Property detail page
'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { 
  FiHeart, FiShare2, FiMapPin, FiCheckCircle, FiX,
  FiHome, FiBed, FiDroplet, FiWifi, FiCoffee, FiCar 
} from 'react-icons/fi';

interface Property {
  id: string;
  title: string;
  description: string;
  rent_lkr: number;
  property_type: string;
  bedrooms: number;
  bathrooms: number;
  furnished: string;
  city: string;
  address: string;
  amenities: string[];
  photos: { url: string; is_primary: boolean }[];
  is_verified: boolean;
  owner_name: string;
  nearest_university_name?: string;
  distance_label?: string;
  similar_properties: any[];
}

export default function PropertyDetailPage() {
  const params = useParams();
  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);
  const [showEnquiryModal, setShowEnquiryModal] = useState(false);
  const [enquiryMessage, setEnquiryMessage] = useState('');

  useEffect(() => {
    fetchProperty();
  }, [params.id]);

  const fetchProperty = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/listings/${params.id}`);
      const data = await response.json();
      setProperty(data);
    } catch (error) {
      console.error('Error fetching property:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEnquiry = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/enquiries`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          property_id: params.id,
          message: enquiryMessage,
        }),
      });

      if (response.ok) {
        alert('Enquiry sent successfully!');
        setShowEnquiryModal(false);
        setEnquiryMessage('');
      }
    } catch (error) {
      console.error('Enquiry error:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-ocean-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-stone-600">Loading property...</p>
        </div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-stone-900 mb-2">Property Not Found</h1>
          <p className="text-stone-600">This listing may have been removed or is no longer available.</p>
        </div>
      </div>
    );
  }

  const amenityIcons: { [key: string]: any } = {
    wifi: FiWifi,
    water: FiDroplet,
    parking: FiCar,
    ac: FiCoffee,
  };

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Photo Gallery */}
      <div className="bg-stone-900 relative">
        <div className="container-custom py-6">
          {/* Main photo */}
          <div className="aspect-[16/9] bg-stone-800 rounded-xl overflow-hidden mb-4">
            {property.photos.length > 0 && (
              <img
                src={property.photos[selectedPhotoIndex]?.url}
                alt={property.title}
                className="w-full h-full object-cover"
              />
            )}
            
            {/* Photo counter */}
            <div className="absolute bottom-4 right-4 bg-stone-900/80 text-white px-4 py-2 rounded-lg">
              {selectedPhotoIndex + 1} / {property.photos.length}
            </div>
          </div>

          {/* Thumbnail strip */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {property.photos.map((photo, index) => (
              <button
                key={index}
                onClick={() => setSelectedPhotoIndex(index)}
                className={`flex-shrink-0 w-24 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                  selectedPhotoIndex === index ? 'border-ocean-500 scale-105' : 'border-transparent'
                }`}
              >
                <img src={photo.url} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="container-custom py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left column - Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header */}
            <div className="card">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    {property.is_verified && (
                      <span className="badge badge-verified">
                        <FiCheckCircle className="w-4 h-4" />
                        Verified
                      </span>
                    )}
                    {property.distance_label && (
                      <span className="badge badge-distance">
                        <FiMapPin className="w-4 h-4" />
                        {property.distance_label}
                      </span>
                    )}
                  </div>
                  <h1 className="heading-md mb-2">{property.title}</h1>
                  <p className="text-stone-600 flex items-center gap-2">
                    <FiMapPin className="w-4 h-4" />
                    {property.address}, {property.city}
                  </p>
                </div>

                <div className="flex gap-2">
                  <button className="p-3 rounded-lg bg-stone-100 hover:bg-stone-200 transition-colors">
                    <FiShare2 className="w-5 h-5 text-stone-600" />
                  </button>
                  <button className="p-3 rounded-lg bg-stone-100 hover:bg-stone-200 transition-colors">
                    <FiHeart className="w-5 h-5 text-stone-600" />
                  </button>
                </div>
              </div>

              {/* Key details */}
              <div className="grid grid-cols-4 gap-4 py-6 border-y border-stone-200">
                <div>
                  <div className="text-2xl font-display font-bold text-ocean-600">
                    LKR {property.rent_lkr.toLocaleString()}
                  </div>
                  <div className="text-sm text-stone-600">per month</div>
                </div>
                <div>
                  <div className="text-2xl font-display font-bold text-stone-900">
                    {property.bedrooms}
                  </div>
                  <div className="text-sm text-stone-600">Bedrooms</div>
                </div>
                <div>
                  <div className="text-2xl font-display font-bold text-stone-900">
                    {property.bathrooms}
                  </div>
                  <div className="text-sm text-stone-600">Bathrooms</div>
                </div>
                <div>
                  <div className="text-lg font-display font-bold text-stone-900 capitalize">
                    {property.furnished}
                  </div>
                  <div className="text-sm text-stone-600">Furnished</div>
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="card">
              <h2 className="font-display font-semibold text-xl mb-4">Description</h2>
              <p className="text-stone-700 leading-relaxed whitespace-pre-line">
                {property.description}
              </p>
            </div>

            {/* Amenities */}
            <div className="card">
              <h2 className="font-display font-semibold text-xl mb-4">Amenities</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {property.amenities.map((amenity) => {
                  const Icon = amenityIcons[amenity] || FiCheckCircle;
                  return (
                    <div key={amenity} className="flex items-center gap-2">
                      <Icon className="w-5 h-5 text-ocean-600" />
                      <span className="capitalize">{amenity.replace('_', ' ')}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Similar Properties */}
            {property.similar_properties?.length > 0 && (
              <div>
                <h2 className="font-display font-semibold text-xl mb-4">Similar Properties</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  {property.similar_properties.map((similar) => (
                    <div key={similar.id} className="card card-hover cursor-pointer">
                      <div className="aspect-[4/3] bg-stone-200 rounded-lg mb-3" />
                      <h3 className="font-semibold mb-2">{similar.title}</h3>
                      <p className="text-ocean-600 font-bold">
                        LKR {similar.rent_lkr.toLocaleString()}/month
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right column - Enquiry form */}
          <div className="lg:col-span-1">
            <div className="card sticky top-24">
              <h2 className="font-display font-semibold text-xl mb-4">Contact Owner</h2>
              
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-12 h-12 bg-ocean-100 rounded-full flex items-center justify-center">
                    <FiHome className="w-6 h-6 text-ocean-600" />
                  </div>
                  <div>
                    <div className="font-semibold">{property.owner_name}</div>
                    <div className="text-sm text-stone-600">Property Owner</div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowEnquiryModal(true)}
                className="btn btn-primary w-full mb-3"
              >
                Send Enquiry
              </button>
              
              <p className="text-xs text-stone-500 text-center">
                Owner details revealed after first message
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Enquiry Modal */}
      {showEnquiryModal && (
        <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="card max-w-lg w-full animate-scale-in">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display font-semibold text-xl">Send Enquiry</h2>
              <button
                onClick={() => setShowEnquiryModal(false)}
                className="p-2 hover:bg-stone-100 rounded-lg transition-colors"
              >
                <FiX className="w-5 h-5" />
              </button>
            </div>

            <div className="mb-6">
              <p className="text-sm text-stone-600 mb-4">
                Send a message to the property owner. They'll be notified immediately.
              </p>
              <textarea
                value={enquiryMessage}
                onChange={(e) => setEnquiryMessage(e.target.value)}
                placeholder="I'm interested in this property. Is it still available?"
                rows={6}
                className="input resize-none"
                minLength={20}
              />
              <p className="text-xs text-stone-500 mt-2">Minimum 20 characters</p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowEnquiryModal(false)}
                className="btn btn-ghost flex-1"
              >
                Cancel
              </button>
              <button
                onClick={handleEnquiry}
                disabled={enquiryMessage.length < 20}
                className="btn btn-primary flex-1 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Send Message
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
