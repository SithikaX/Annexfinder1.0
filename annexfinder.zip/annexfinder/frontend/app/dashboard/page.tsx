// app/dashboard/page.tsx - Owner dashboard with analytics
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  FiHome, FiEye, FiMessageSquare, FiHeart, FiTrendingUp,
  FiPlus, FiEdit2, FiPause, FiTrash2, FiBarChart2
} from 'react-icons/fi';

interface DashboardStats {
  subscription: {
    plan: string;
    expires_at: string;
    is_active: boolean;
  };
  listing_counts: {
    active: number;
    pending: number;
    paused: number;
    rented: number;
  };
  totals: {
    views: number;
    enquiries: number;
    saves: number;
    enquiry_rate: string;
  };
  recent_enquiries: any[];
}

interface Listing {
  id: string;
  title: string;
  rent_lkr: number;
  status: string;
  view_count: number;
  enquiry_count: number;
  photo_url: string;
  is_boosted: boolean;
  created_at: string;
}

export default function OwnerDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const token = localStorage.getItem('token');
      
      // Fetch stats
      const statsRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/owner/stats`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      const statsData = await statsRes.json();
      setStats(statsData);

      // Fetch listings
      const listingsRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/owner/listings`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      const listingsData = await listingsRes.json();
      setListings(listingsData);
    } catch (error) {
      console.error('Dashboard error:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-ocean-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const enquiryRateValue = parseFloat(stats?.totals.enquiry_rate || '0');
  const enquiryRateColor = enquiryRateValue >= 6.5 ? 'text-emerald-600' : enquiryRateValue >= 5 ? 'text-sunset-600' : 'text-red-600';

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <header className="bg-white border-b border-stone-200">
        <div className="container-custom">
          <div className="flex items-center justify-between h-20">
            <div>
              <h1 className="heading-sm">Owner Dashboard</h1>
              <p className="text-sm text-stone-600">Manage your properties and track performance</p>
            </div>
            <Link href="/list-property" className="btn btn-primary">
              <FiPlus className="w-5 h-5" />
              Add New Listing
            </Link>
          </div>
        </div>
      </header>

      <div className="container-custom py-8">
        {/* Subscription Banner */}
        {stats?.subscription && (
          <div className={`card mb-8 ${
            !stats.subscription.is_active 
              ? 'bg-gradient-to-r from-red-50 to-red-100 border-red-200' 
              : 'bg-gradient-to-r from-ocean-50 to-ocean-100 border-ocean-200'
          }`}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display font-semibold text-lg mb-1">
                  {stats.subscription.plan.toUpperCase()} Plan
                </h3>
                <p className="text-sm text-stone-600">
                  {stats.subscription.is_active 
                    ? `Expires on ${new Date(stats.subscription.expires_at).toLocaleDateString()}`
                    : 'Plan expired - Your listings are paused'
                  }
                </p>
              </div>
              {!stats.subscription.is_active && (
                <Link href="/billing" className="btn btn-accent">
                  Renew Now
                </Link>
              )}
            </div>
          </div>
        )}

        {/* Metric Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="card">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-ocean-100 rounded-lg flex items-center justify-center">
                <FiEye className="w-6 h-6 text-ocean-600" />
              </div>
              <div>
                <div className="text-sm text-stone-600">Total Views</div>
                <div className="text-2xl font-display font-bold text-stone-900">
                  {stats?.totals.views || 0}
                </div>
              </div>
            </div>
            <div className="text-xs text-stone-500">Last 30 days</div>
          </div>

          <div className="card">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-sunset-100 rounded-lg flex items-center justify-center">
                <FiMessageSquare className="w-6 h-6 text-sunset-600" />
              </div>
              <div>
                <div className="text-sm text-stone-600">Enquiries</div>
                <div className="text-2xl font-display font-bold text-stone-900">
                  {stats?.totals.enquiries || 0}
                </div>
              </div>
            </div>
            <div className="text-xs text-stone-500">Last 30 days</div>
          </div>

          <div className="card">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-copper-100 rounded-lg flex items-center justify-center">
                <FiHeart className="w-6 h-6 text-copper-600" />
              </div>
              <div>
                <div className="text-sm text-stone-600">Saves</div>
                <div className="text-2xl font-display font-bold text-stone-900">
                  {stats?.totals.saves || 0}
                </div>
              </div>
            </div>
            <div className="text-xs text-stone-500">Last 30 days</div>
          </div>

          <div className="card">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center">
                <FiTrendingUp className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <div className="text-sm text-stone-600">Enquiry Rate</div>
                <div className={`text-2xl font-display font-bold ${enquiryRateColor}`}>
                  {stats?.totals.enquiry_rate}%
                </div>
              </div>
            </div>
            <div className="text-xs text-stone-500">
              {enquiryRateValue >= 6.5 ? 'Excellent!' : enquiryRateValue >= 5 ? 'Good' : 'Needs improvement'}
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Enquiries */}
          <div className="lg:col-span-1">
            <div className="card">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-display font-semibold text-xl">Recent Enquiries</h2>
                <Link href="/enquiries" className="text-sm text-ocean-600 hover:text-ocean-700">
                  View All
                </Link>
              </div>

              <div className="space-y-4">
                {stats?.recent_enquiries.length === 0 ? (
                  <p className="text-center text-stone-500 py-8">No enquiries yet</p>
                ) : (
                  stats?.recent_enquiries.map((enquiry) => (
                    <div key={enquiry.id} className="border-b border-stone-200 pb-4 last:border-0">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="font-semibold text-sm">{enquiry.tenant_name}</div>
                          <div className="text-xs text-stone-600">{enquiry.property_title}</div>
                        </div>
                        <span className={`badge ${
                          enquiry.status === 'replied' ? 'badge-verified' : 'badge-distance'
                        } text-xs`}>
                          {enquiry.status}
                        </span>
                      </div>
                      <p className="text-sm text-stone-600 line-clamp-2">{enquiry.last_message}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Listings */}
          <div className="lg:col-span-2">
            <div className="card">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-display font-semibold text-xl">Your Listings</h2>
                <div className="flex gap-2">
                  <span className="badge bg-emerald-100 text-emerald-700">
                    {stats?.listing_counts.active} Active
                  </span>
                  <span className="badge bg-sunset-100 text-sunset-700">
                    {stats?.listing_counts.pending} Pending
                  </span>
                </div>
              </div>

              <div className="space-y-3">
                {listings.length === 0 ? (
                  <div className="text-center py-12">
                    <FiHome className="w-16 h-16 text-stone-300 mx-auto mb-4" />
                    <p className="text-stone-600 mb-4">No listings yet</p>
                    <Link href="/list-property" className="btn btn-primary">
                      Create Your First Listing
                    </Link>
                  </div>
                ) : (
                  listings.map((listing) => (
                    <div
                      key={listing.id}
                      className="flex gap-4 p-4 rounded-lg border border-stone-200 hover:border-ocean-300 transition-colors"
                    >
                      {/* Thumbnail */}
                      <div className="w-24 h-20 flex-shrink-0 bg-stone-200 rounded-lg overflow-hidden">
                        {listing.photo_url && (
                          <img
                            src={listing.photo_url}
                            alt={listing.title}
                            className="w-full h-full object-cover"
                          />
                        )}
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <h3 className="font-semibold truncate mb-1">{listing.title}</h3>
                            <p className="text-sm text-stone-600">
                              LKR {listing.rent_lkr.toLocaleString()}/month
                            </p>
                          </div>
                          <span className={`badge text-xs ${
                            listing.status === 'active' ? 'badge-verified' :
                            listing.status === 'pending' ? 'badge-distance' :
                            'bg-stone-200 text-stone-700'
                          }`}>
                            {listing.status}
                          </span>
                        </div>

                        <div className="flex items-center gap-4 text-sm text-stone-600">
                          <span className="flex items-center gap-1">
                            <FiEye className="w-4 h-4" />
                            {listing.view_count}
                          </span>
                          <span className="flex items-center gap-1">
                            <FiMessageSquare className="w-4 h-4" />
                            {listing.enquiry_count}
                          </span>
                          {listing.is_boosted && (
                            <span className="badge badge-boosted text-xs">
                              <FiTrendingUp className="w-3 h-3" />
                              Boosted
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-col gap-2">
                        <Link
                          href={`/property/${listing.id}`}
                          className="p-2 rounded-lg bg-stone-100 hover:bg-stone-200 transition-colors"
                        >
                          <FiEye className="w-4 h-4" />
                        </Link>
                        <Link
                          href={`/edit-listing/${listing.id}`}
                          className="p-2 rounded-lg bg-stone-100 hover:bg-stone-200 transition-colors"
                        >
                          <FiEdit2 className="w-4 h-4" />
                        </Link>
                        <Link
                          href={`/analytics/${listing.id}`}
                          className="p-2 rounded-lg bg-stone-100 hover:bg-stone-200 transition-colors"
                        >
                          <FiBarChart2 className="w-4 h-4" />
                        </Link>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
