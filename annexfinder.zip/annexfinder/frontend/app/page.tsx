'use client'

import { useState } from 'react'
import { HiSearch, HiLocationMarker, HiAcademicCap, HiBriefcase, HiCheckCircle, HiHeart } from 'react-icons/hi'

export default function HomePage() {
  const [searchMode, setSearchMode] = useState<'university' | 'workplace'>('university')
  const [searchQuery, setSearchQuery] = useState('')

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-ocean-600 via-ocean-500 to-sunset-500">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-white rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-white rounded-full blur-3xl" style={{ animationDelay: '1s' }} />
        </div>

        <div className="relative container-custom py-20 md:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6">
              Find Your Perfect
              <br />
              <span className="text-sunset-200">Place to Stay</span>
            </h1>

            <p className="text-xl md:text-2xl text-ocean-100 mb-12">
              Student housing near universities across Sri Lanka
            </p>

            <div className="card p-8">
              <div className="flex gap-4 mb-6 justify-center">
                <button
                  onClick={() => setSearchMode('university')}
                  className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
                    searchMode === 'university'
                      ? 'bg-ocean-500 text-white shadow-soft'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  <HiAcademicCap className="w-5 h-5" />
                  Near University
                </button>
                <button
                  onClick={() => setSearchMode('workplace')}
                  className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
                    searchMode === 'workplace'
                      ? 'bg-ocean-500 text-white shadow-soft'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  <HiBriefcase className="w-5 h-5" />
                  Near Workplace
                </button>
              </div>

              <div className="relative">
                <HiLocationMarker className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 text-stone-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={searchMode === 'university' ? 'University of Colombo' : 'Your workplace address'}
                  className="w-full pl-14 pr-32 py-5 text-lg rounded-xl border-2 border-stone-200 focus:border-ocean-400 focus:outline-none focus:ring-4 focus:ring-ocean-100"
                />
                <button className="absolute right-2 top-1/2 -translate-y-1/2 btn-primary flex items-center gap-2">
                  <HiSearch className="w-5 h-5" />
                  Search
                </button>
              </div>

              <div className="mt-6 flex flex-wrap gap-2 justify-center">
                <span className="text-sm text-stone-500">Popular:</span>
                {['Colombo', 'Peradeniya', 'Moratuwa', 'Kelaniya'].map((city) => (
                  <button key={city} className="px-4 py-1.5 rounded-full bg-ocean-50 text-ocean-700 text-sm font-medium hover:bg-ocean-100">
                    {city}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" className="w-full">
            <path d="M0 0L60 8C120 16 240 32 360 42.7C480 53 600 59 720 58.7C840 59 960 53 1080 48C1200 43 1320 37 1380 34.7L1440 32V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0V0Z" fill="#F9FAFB"/>
          </svg>
        </div>
      </section>

      {/* Trust indicators */}
      <section className="section bg-stone-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-5xl font-bold text-ocean-600 mb-2 font-display">2,400+</div>
              <div className="text-stone-600">Properties</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-ocean-600 mb-2 font-display">15</div>
              <div className="text-stone-600">Cities</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-ocean-600 mb-2 font-display">8,500+</div>
              <div className="text-stone-600">Tenants</div>
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="section bg-white">
        <div className="container-custom">
          <div className="text-center mb-16">
            <div className="decorative-line mx-auto mb-4" />
            <h2 className="font-display text-4xl md:text-5xl font-bold text-stone-900 mb-4">How It Works</h2>
            <p className="text-xl text-stone-600 max-w-2xl mx-auto">Finding your perfect place is simple</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-ocean-400 to-ocean-600 flex items-center justify-center shadow-soft-lg">
                <HiSearch className="w-10 h-10 text-white" />
              </div>
              <h3 className="font-display text-2xl font-bold text-stone-900 mb-3">1. Search</h3>
              <p className="text-stone-600">Find properties near your university with distance-based search</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-sunset-400 to-sunset-600 flex items-center justify-center shadow-soft-lg">
                <HiHeart className="w-10 h-10 text-white" />
              </div>
              <h3 className="font-display text-2xl font-bold text-stone-900 mb-3">2. Save</h3>
              <p className="text-stone-600">Bookmark favorites and compare amenities</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-copper-400 to-copper-600 flex items-center justify-center shadow-soft-lg">
                <HiCheckCircle className="w-10 h-10 text-white" />
              </div>
              <h3 className="font-display text-2xl font-bold text-stone-900 mb-3">3. Connect</h3>
              <p className="text-stone-600">Message owners and arrange visits</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-stone-900 text-white py-12">
        <div className="container-custom text-center">
          <p className="text-stone-400">&copy; 2026 AnnexFinder. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
