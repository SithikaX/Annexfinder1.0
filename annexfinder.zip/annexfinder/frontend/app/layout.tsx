// app/layout.tsx - Root layout with distinctive Sri Lankan modern design
import type { Metadata } from 'next'
import { Bricolage_Grotesque, Inter } from 'next/font/google'
import './globals.css'

// Distinctive display font - geometric, friendly, professional
const bricolage = Bricolage_Grotesque({
  subsets: ['latin'],
  variable: '--font-bricolage',
  display: 'swap',
  weight: ['400', '500', '600', '700', '800'],
})

// Clean body font
const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'AnnexFinder | Student & Professional Housing in Sri Lanka',
  description: 'Find annexes, rooms, and apartments near universities and workplaces across Sri Lanka',
  keywords: 'annex Sri Lanka, student housing, rooms for rent, Colombo accommodation',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${bricolage.variable} ${inter.variable}`}>
      <head>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
      </head>
      <body className="font-body bg-stone-50 text-stone-900 antialiased">
        {children}
      </body>
    </html>
  )
}
