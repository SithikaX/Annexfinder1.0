// app/search/page.tsx - Search results with map + list view
'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import dynamic from 'next/dynamic';
import { FiMap, FiList, FiFilter, FiHeart, FiCheckCircle, FiTrendingUp } from 'react-icons/fi';

// Dynamically import map to avoid SSR issues
const PropertyMap = dynamic(() => import('../../components/PropertyMap'), { ssr: false });

interface Property {
  id: string;
  title: string;
  rent_lkr: number;
  property_type: string;
  bedrooms: number;
  furnished: string;
  is_verified: boolean;
  is_boosted: boolean;
  distance_metres: number;
  distance_label: string;
  photo_url: string;
  city: string;
}

function SearchResults() {
  const searchParams = useSearchParams();
  const [view, setView] = useState<'split' | 'list' | 'map'>('split');
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  
  // Filters
  const [filters, setFilters] = useState({
    minRent: '',
    maxRent: '',
    type: '',
    furnished: '',
    bedrooms: '',
    radius: '3000',
  });

  const uni = searchParams.get('uni');
  const lat = searchParams.get('lat');
  const lng = searchParams.get('lng');

  useEffect(() => {
    fetchProperties();
  }, [uni, lat, lng, filters]);

  const fetchProperties = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (uni) params.set('uni', uni);
      if (lat && lng) {
        params.set('lat', lat);
        params.set('lng', lng);
      }
      
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.set(key, value);
      });

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/search?${params}`);
      const data = await response.json();
      setProperties(data.results || []);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-40">
        <div className="container-custom">
          <div className="flex items-center justify-between h-16">
            <div>
              <h1 className="font-display text-xl font-bold">
                {uni ? `Near ${uni}` : 'Search Results'}
              </h1>
              <p className="text-sm text-stone-600">{properties.length} properties found</p>
            </div>

            {/* View toggles */}
            <div className="flex gap-2">
              <button
                onClick={() => setView('list')}
                className={`p-2 rounded-lg ${view === 'list' ? 'bg-ocean-500 text-white' : 'bg-stone-100 text-stone-600'}`}
              >
                <FiList className="w-5 h-5" />
              </button>
              <button
                onClick={() => setView('split')}
                className={`p-2 rounded-lg ${view === 'split' ? 'bg-ocean-500 text-white' : 'bg-stone-100 text-stone-600'}`}
              >
                <FiMap className="w-5 h-5" />
              </button>
              <button
                onClick={() => setView('map')}
                className={`p-2 rounded-lg ${view === 'map' ? 'bg-ocean-500 text-white' : 'bg-stone-100 text-stone-600'}`}
              >
                <FiMap className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="container-custom py-6">
        <div className={`grid ${view === 'split' ? 'lg:grid-cols-2' : 'grid-cols-1'} gap-6`}>
          {/* Filters sidebar (mobile: collapsible) */}
          <div className={`${view === 'map' ? 'hidden' : 'block'} lg:col-span-2`}>
            <div className="card mb-6">
              <div className="flex items-center gap-2 mb-4">
                <FiFilter className="w-5 h-5 text-ocean-600" />
                <h2 className="font-display font-semibold text-lg">Filters</h2>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Min Rent</label>
                  <input
                    type="number"
                    value={filters.minRent}
                    onChange={(e) => setFilters({ ...filters, minRent: e.target.value })}
                    placeholder="5,000"
                    className="input"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Max Rent</label>
                  <input
                    type="number"
                    value={filters.maxRent}
                    onChange={(e) => setFilters({ ...filters, maxRent: e.target.value })}
                    placeholder="50,000"
                    className="input"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Type</label>
                  <select
                    value={filters.type}
                    onChange={(e) => setFilters({ ...filters, type: e.target.value })}
                    className="input"
                  >
                    <option value="">All Types</option>
                    <option value="annex">Annex</option>
                    <option value="room">Room</option>
                    <option value="apartment">Apartment</option>
                    <option value="house">House</option>
                    <option value="boarding">Boarding</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Furnished</label>
                  <select
                    value={filters.furnished}
                    onChange={(e) => setFilters({ ...filters, furnished: e.target.value })}
                    className="input"
                  >
                    <option value="">Any</option>
                    <option value="furnished">Furnished</option>
                    <option value="semi">Semi-furnished</option>
                    <option value="unfurnished">Unfurnished</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Bedrooms</label>
                  <select
                    value={filters.bedrooms}
                    onChange={(e) => setFilters({ ...filters, bedrooms: e.target.value })}
                    className="input"
                  >
                    <option value="">Any</option>
                    <option value="1">1+</option>
                    <option value="2">2+</option>
                    <option value="3">3+</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Radius</label>
                  <select
                    value={filters.radius}
                    onChange={(e) => setFilters({ ...filters, radius: e.target.value })}
                    className="input"
                  >
                    <option value="1000">1 km</option>
                    <option value="2000">2 km</option>
                    <option value="3000">3 km</option>
                    <option value="5000">5 km</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Listings */}
          {view !== 'map' && (
            <div className="space-y-4">
              {loading ? (
                // Loading skeletons
                [...Array(6)].map((_, i) => (
                  <div key={i} className="card">
                    <div className="flex gap-4">
                      <div className="w-48 h-36 skeleton" />
                      <div className="flex-1 space-y-3">
                        <div className="h-6 skeleton w-3/4" />
                        <div className="h-4 skeleton w-1/2" />
                        <div className="h-8 skeleton w-32" />
                      </div>
                    </div>
                  </div>
                ))
              ) : properties.length === 0 ? (
                <div className="card text-center py-12">
                  <p className="text-stone-600">No properties found. Try adjusting your filters.</p>
                </div>
              ) : (
                properties.map((property) => (
                  <div
                    key={property.id}
                    onMouseEnter={() => setHoveredId(property.id)}
                    onMouseLeave={() => setHoveredId(null)}
                    className={`card card-hover cursor-pointer ${hoveredId === property.id ? 'ring-2 ring-ocean-500' : ''}`}
                    onClick={() => window.location.href = `/property/${property.id}`}
                  >
                    <div className="flex gap-4">
                      {/* Image */}
                      <div className="w-48 h-36 flex-shrink-0 bg-stone-200 rounded-lg relative overflow-hidden">
                        {property.photo_url && (
                          <img
                            src={property.photo_url}
                            alt={property.title}
                            className="w-full h-full object-cover"
                          />
                        )}
                        <div className="absolute top-2 left-2 flex flex-col gap-1">
                          {property.is_verified && (
                            <span className="badge badge-verified text-xs">
                              <FiCheckCircle className="w-3 h-3" />
                              Verified
                            </span>
                          )}
                          {property.is_boosted && (
                            <span className="badge badge-boosted text-xs">
                              <FiTrendingUp className="w-3 h-3" />
                              Featured
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-display font-semibold text-lg mb-2 truncate">
                          {property.title}
                        </h3>
                        <p className="text-stone-600 text-sm mb-3">
                          {property.city} • {property.bedrooms} Bedrooms • {property.furnished}
                        </p>
                        <div className="flex items-center gap-4">
                          <div>
                            <span className="text-2xl font-display font-bold text-ocean-600">
                              LKR {property.rent_lkr.toLocaleString()}
                            </span>
                            <span className="text-stone-500 text-sm">/month</span>
                          </div>
                          <span className="badge badge-distance">
                            {property.distance_label}
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-col justify-between items-end">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            // Toggle save
                          }}
                          className="p-2 rounded-lg hover:bg-stone-100 transition-colors"
                        >
                          <FiHeart className="w-5 h-5 text-stone-400" />
                        </button>
                        <button className="btn btn-primary btn-sm">View Details</button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Map */}
          {(view === 'split' || view === 'map') && (
            <div className={`${view === 'map' ? 'h-[calc(100vh-12rem)]' : 'h-[600px]'} sticky top-24`}>
              <div className="map-container h-full">
                <PropertyMap
                  properties={properties}
                  center={lat && lng ? { lat: parseFloat(lat), lng: parseFloat(lng) } : undefined}
                  hoveredId={hoveredId}
                  onMarkerClick={(id) => window.location.href = `/property/${id}`}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <SearchResults />
    </Suspense>
  );
}
