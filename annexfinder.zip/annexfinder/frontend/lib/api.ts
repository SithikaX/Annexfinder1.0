// lib/api.ts - API client for backend communication
import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

const api = axios.create({
  baseURL: `${API_URL}/api`,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/auth/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (data: any) => api.post('/auth/register', data),
  login: (data: any) => api.post('/auth/login', data),
  verifyEmail: (token: string) => api.post('/auth/verify-email', { token }),
  forgotPassword: (email: string) => api.post('/auth/forgot-password', { email }),
  resetPassword: (token: string, newPassword: string) => 
    api.post('/auth/reset-password', { token, newPassword }),
};

// Search API
export const searchAPI = {
  search: (params: any) => api.get('/search', { params }),
  universities: (q?: string) => api.get('/search/universities', { params: { q } }),
  cities: () => api.get('/search/cities'),
  featured: () => api.get('/search/featured'),
};

// Listings API
export const listingsAPI = {
  getById: (id: string) => api.get(`/listings/${id}`),
  create: (data: any) => api.post('/listings', data),
  update: (id: string, data: any) => api.patch(`/listings/${id}`, data),
  updateStatus: (id: string, status: string) => 
    api.patch(`/listings/${id}/status`, { status }),
  delete: (id: string) => api.delete(`/listings/${id}`),
  similar: (id: string, limit?: number) => 
    api.get(`/listings/${id}/similar`, { params: { limit } }),
};

// Enquiries API
export const enquiriesAPI = {
  create: (propertyId: string, message: string) =>
    api.post('/enquiries', { property_id: propertyId, message }),
  list: (params?: any) => api.get('/enquiries', { params }),
  getMessages: (id: string) => api.get(`/enquiries/${id}/messages`),
  sendMessage: (id: string, content: string) =>
    api.post(`/enquiries/${id}/messages`, { content }),
  updateStatus: (id: string, status: string) =>
    api.patch(`/enquiries/${id}/status`, { status }),
};

// Owner API
export const ownerAPI = {
  stats: () => api.get('/owner/stats'),
  analytics: (period?: string) => api.get('/owner/analytics', { params: { period } }),
  listings: (status?: string) => api.get('/owner/listings', { params: { status } }),
};

// Admin API
export const adminAPI = {
  listings: (params: any) => api.get('/admin/listings', { params }),
  approve: (id: string) => api.patch(`/admin/listings/${id}/approve`),
  reject: (id: string, reason: string) => 
    api.patch(`/admin/listings/${id}/reject`, { reason }),
  users: (params: any) => api.get('/admin/users', { params }),
  suspend: (id: string, reason: string) => 
    api.patch(`/admin/users/${id}/suspend`, { reason }),
  unsuspend: (id: string) => api.patch(`/admin/users/${id}/unsuspend`),
  stats: (period?: number) => api.get('/admin/stats', { params: { period } }),
};

// Payments API
export const paymentsAPI = {
  subscriptionCheckout: (plan: string) => 
    api.post('/payments/subscription/checkout', { plan }),
  boostCheckout: (listingId: string, durationDays: number) =>
    api.post('/payments/boost/checkout', { listing_id: listingId, duration_days: durationDays }),
  history: () => api.get('/payments/history'),
};

export default api;
