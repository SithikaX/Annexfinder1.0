'use client'

// components/PropertyCard.tsx - Reusable property listing card
import Link from 'next/link'
import { HiHeart, HiLocationMarker, HiBadgeCheck, HiStar } from 'react-icons/hi'
import { useState } from 'react'

interface PropertyCardProps {
  property: {
    id: string
    title: string
    rent_lkr: number
    property_type: string
    bedrooms?: number
    bathrooms?: number
    furnished?: string
    city?: string
    is_verified?: boolean
    is_boosted?: boolean
    is_saved?: boolean
    distance_metres?: number
    distance_label?: string
    photo_url?: string
  }
  onSave?: (id: string) => void
}

export default function PropertyCard({ property, onSave }: PropertyCardProps) {
  const [isSaved, setIsSaved] = useState(property.is_saved || false)

  const handleSave = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsSaved(!isSaved)
    onSave?.(property.id)
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-LK', {
      style: 'currency',
      currency: 'LKR',
      minimumFractionDigits: 0,
    }).format(price)
  }

  const formatPropertyType = (type: string) => {
    return type.charAt(0).toUpperCase() + type.slice(1)
  }

  return (
    <Link href={`/property/${property.id}`}>
      <div className="card-interactive overflow-hidden h-full">
        {/* Image */}
        <div className="relative aspect-[4/3] bg-stone-200">
          {property.photo_url ? (
            <img
              src={property.photo_url}
              alt={property.title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-stone-400">
              <HiLocationMarker className="w-16 h-16" />
            </div>
          )}

          {/* Save button */}
          <button
            onClick={handleSave}
            className="absolute top-3 right-3 w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-all duration-200 shadow-soft"
          >
            <HiHeart 
              className={`w-5 h-5 ${
                isSaved 
                  ? 'fill-sunset-500 text-sunset-500' 
                  : 'text-stone-400 hover:text-sunset-500'
              }`} 
            />
          </button>

          {/* Badges */}
          <div className="absolute top-3 left-3 flex gap-2">
            {property.is_boosted && (
              <span className="badge-boosted flex items-center gap-1">
                <HiStar className="w-3 h-3" />
                Featured
              </span>
            )}
            {property.is_verified && (
              <span className="badge-verified flex items-center gap-1">
                <HiBadgeCheck className="w-3 h-3" />
                Verified
              </span>
            )}
          </div>

          {/* Distance label */}
          {property.distance_label && (
            <div className="absolute bottom-3 left-3">
              <span className="distance-badge">
                <HiLocationMarker className="w-4 h-4" />
                {property.distance_label}
              </span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4">
          {/* Price */}
          <div className="text-2xl font-bold text-ocean-600 mb-2 font-display">
            {formatPrice(property.rent_lkr)}
            <span className="text-sm text-stone-500 font-normal">/month</span>
          </div>

          {/* Title */}
          <h3 className="font-semibold text-stone-900 mb-2 line-clamp-2 min-h-[3rem]">
            {property.title}
          </h3>

          {/* Details */}
          <div className="flex items-center gap-3 text-sm text-stone-600 mb-2">
            <span className="flex items-center gap-1">
              <span className="font-medium">{formatPropertyType(property.property_type)}</span>
            </span>
            {property.bedrooms !== undefined && (
              <>
                <span className="text-stone-300">•</span>
                <span>{property.bedrooms} Bed</span>
              </>
            )}
            {property.bathrooms !== undefined && (
              <>
                <span className="text-stone-300">•</span>
                <span>{property.bathrooms} Bath</span>
              </>
            )}
          </div>

          {/* Location & Furnished */}
          <div className="flex items-center justify-between text-xs text-stone-500">
            {property.city && (
              <span className="flex items-center gap-1">
                <HiLocationMarker className="w-3 h-3" />
                {property.city}
              </span>
            )}
            {property.furnished && (
              <span className="px-2 py-1 rounded-md bg-stone-100 text-stone-700 font-medium">
                {property.furnished === 'furnished' ? 'Furnished' : 
                 property.furnished === 'semi' ? 'Semi-Furnished' : 
                 'Unfurnished'}
              </span>
            )}
          </div>
        </div>
      </div>
    </Link>
  )
}
