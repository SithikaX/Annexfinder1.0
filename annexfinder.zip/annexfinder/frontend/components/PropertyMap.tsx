// components/PropertyMap.tsx - Interactive map with property markers
'use client';

import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface Property {
  id: string;
  title: string;
  rent_lkr: number;
  lat?: number;
  lng?: number;
  is_boosted?: boolean;
  distance_label?: string;
}

interface PropertyMapProps {
  properties: Property[];
  center?: { lat: number; lng: number };
  hoveredId?: string | null;
  onMarkerClick?: (id: string) => void;
}

export default function PropertyMap({ properties, center, hoveredId, onMarkerClick }: PropertyMapProps) {
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});

  useEffect(() => {
    // Initialize map only once
    if (!mapRef.current) {
      const defaultCenter: [number, number] = center 
        ? [center.lat, center.lng] 
        : [6.9271, 79.8612]; // Colombo default

      mapRef.current = L.map('map').setView(defaultCenter, 13);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
      }).addTo(mapRef.current);
    }

    return () => {
      // Cleanup on unmount
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!mapRef.current) return;

    // Clear existing markers
    Object.values(markersRef.current).forEach(marker => marker.remove());
    markersRef.current = {};

    // Add markers for each property
    properties.forEach(property => {
      if (!property.lat || !property.lng) return;

      const markerIcon = L.divIcon({
        html: `
          <div class="custom-marker ${property.is_boosted ? 'boosted' : ''} ${hoveredId === property.id ? 'scale-125' : ''}">
            <span class="text-sm">LKR ${(property.rent_lkr / 1000).toFixed(0)}k</span>
          </div>
        `,
        className: 'custom-marker-wrapper',
        iconSize: [60, 40],
        iconAnchor: [30, 40],
      });

      const marker = L.marker([property.lat, property.lng], { icon: markerIcon })
        .addTo(mapRef.current!)
        .bindPopup(`
          <div class="p-2">
            <h3 class="font-semibold mb-1">${property.title}</h3>
            <p class="text-sm text-stone-600 mb-2">
              LKR ${property.rent_lkr.toLocaleString()}/month
            </p>
            ${property.distance_label ? `<p class="text-xs text-ocean-600">${property.distance_label}</p>` : ''}
          </div>
        `);

      marker.on('click', () => {
        if (onMarkerClick) {
          onMarkerClick(property.id);
        }
      });

      markersRef.current[property.id] = marker;
    });

    // Fit bounds to show all markers
    if (properties.length > 0) {
      const validCoords = properties
        .filter(p => p.lat && p.lng)
        .map(p => [p.lat!, p.lng!] as [number, number]);
      
      if (validCoords.length > 0) {
        const bounds = L.latLngBounds(validCoords);
        mapRef.current.fitBounds(bounds, { padding: [50, 50] });
      }
    }
  }, [properties, hoveredId]);

  useEffect(() => {
    if (!mapRef.current || !center) return;
    mapRef.current.setView([center.lat, center.lng], 13);
  }, [center]);

  return <div id="map" className="w-full h-full rounded-xl" />;
}
