// components/Navbar.tsx - Main navigation with Sri Lankan modern design
'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useAuthStore } from '@/lib/store';
import { 
  FiHome, FiSearch, FiHeart, FiMessageSquare, 
  FiUser, FiMenu, FiX, FiLogOut, FiGrid 
} from 'react-icons/fi';

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuthStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const tenantLinks = [
    { href: '/', label: 'Home', icon: FiHome },
    { href: '/search', label: 'Search', icon: FiSearch },
    { href: '/saved', label: 'Saved', icon: FiHeart },
    { href: '/enquiries', label: 'Enquiries', icon: FiMessageSquare },
  ];

  const ownerLinks = [
    { href: '/owner/dashboard', label: 'Dashboard', icon: FiGrid },
    { href: '/owner/listings', label: 'My Listings', icon: FiHome },
    { href: '/owner/enquiries', label: 'Enquiries', icon: FiMessageSquare },
  ];

  const links = user?.role === 'owner' ? ownerLinks : tenantLinks;

  return (
    <>
      {/* Desktop Navbar */}
      <nav className="sticky top-0 z-40 bg-white/95 backdrop-blur-xl border-b border-stone-200 shadow-soft">
        <div className="container-custom">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-3 group">
              <div className="w-12 h-12 gradient-ocean rounded-2xl flex items-center justify-center group-hover:scale-105 transition-transform">
                <span className="text-white font-display font-bold text-xl">AF</span>
              </div>
              <div className="hidden sm:block">
                <div className="font-display font-bold text-2xl text-stone-900">
                  AnnexFinder
                </div>
                <div className="text-xs text-stone-500 -mt-1">
                  Student & Pro Housing
                </div>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {isAuthenticated && links.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="flex items-center gap-2 text-stone-600 hover:text-ocean-600 font-medium transition-colors"
                >
                  <link.icon className="w-5 h-5" />
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Auth Actions */}
            <div className="hidden lg:flex items-center gap-4">
              {isAuthenticated ? (
                <>
                  <Link
                    href="/account"
                    className="flex items-center gap-2 px-4 py-2 rounded-xl hover:bg-stone-100 transition-colors"
                  >
                    <FiUser className="w-5 h-5" />
                    <span className="font-medium">{user?.name}</span>
                  </Link>
                  <button
                    onClick={logout}
                    className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                  >
                    <FiLogOut className="w-5 h-5" />
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <Link href="/auth/login" className="btn-secondary">
                    Login
                  </Link>
                  <Link href="/auth/register" className="btn-primary">
                    Get Started
                  </Link>
                </>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl hover:bg-stone-100"
            >
              {mobileMenuOpen ? (
                <FiX className="w-6 h-6" />
              ) : (
                <FiMenu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-20 z-30 bg-white">
          <div className="container-custom py-6 space-y-4">
            {isAuthenticated && links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-3 p-4 rounded-xl hover:bg-stone-50"
              >
                <link.icon className="w-6 h-6 text-ocean-600" />
                <span className="font-medium text-lg">{link.label}</span>
              </Link>
            ))}

            <div className="pt-4 border-t border-stone-200 space-y-3">
              {isAuthenticated ? (
                <>
                  <Link
                    href="/account"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center gap-3 p-4 rounded-xl hover:bg-stone-50"
                  >
                    <FiUser className="w-6 h-6" />
                    <span className="font-medium">My Account</span>
                  </Link>
                  <button
                    onClick={() => {
                      logout();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-3 p-4 rounded-xl hover:bg-red-50 text-red-600"
                  >
                    <FiLogOut className="w-6 h-6" />
                    <span className="font-medium">Logout</span>
                  </button>
                </>
              ) : (
                <>
                  <Link
                    href="/auth/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="block w-full btn-secondary text-center"
                  >
                    Login
                  </Link>
                  <Link
                    href="/auth/register"
                    onClick={() => setMobileMenuOpen(false)}
                    className="block w-full btn-primary text-center"
                  >
                    Get Started
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
