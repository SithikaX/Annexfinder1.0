// components/Footer.tsx - Footer with links and branding
import Link from 'next/link';
import { FiMapPin, FiMail, FiPhone } from 'react-icons/fi';
import { FaWhatsapp, FaFacebook, FaInstagram } from 'react-icons/fa';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-stone-900 text-stone-300">
      <div className="container-custom py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 gradient-ocean rounded-2xl flex items-center justify-center">
                <span className="text-white font-display font-bold text-xl">AF</span>
              </div>
              <div className="font-display font-bold text-2xl text-white">
                AnnexFinder
              </div>
            </div>
            <p className="text-stone-400 mb-6">
              Connecting students and professionals with quality housing across Sri Lanka.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-stone-800 rounded-xl flex items-center justify-center hover:bg-ocean-600 transition-colors">
                <FaWhatsapp className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-stone-800 rounded-xl flex items-center justify-center hover:bg-ocean-600 transition-colors">
                <FaFacebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-stone-800 rounded-xl flex items-center justify-center hover:bg-ocean-600 transition-colors">
                <FaInstagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* For Tenants */}
          <div>
            <h3 className="font-display font-semibold text-white text-lg mb-4">
              For Tenants
            </h3>
            <ul className="space-y-3">
              <li>
                <Link href="/search" className="hover:text-white transition-colors">
                  Search Properties
                </Link>
              </li>
              <li>
                <Link href="/how-it-works" className="hover:text-white transition-colors">
                  How It Works
                </Link>
              </li>
              <li>
                <Link href="/saved" className="hover:text-white transition-colors">
                  Saved Listings
                </Link>
              </li>
              <li>
                <Link href="/safety-tips" className="hover:text-white transition-colors">
                  Safety Tips
                </Link>
              </li>
            </ul>
          </div>

          {/* For Owners */}
          <div>
            <h3 className="font-display font-semibold text-white text-lg mb-4">
              For Owners
            </h3>
            <ul className="space-y-3">
              <li>
                <Link href="/list-property" className="hover:text-white transition-colors">
                  List Your Property
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="hover:text-white transition-colors">
                  Pricing Plans
                </Link>
              </li>
              <li>
                <Link href="/owner/dashboard" className="hover:text-white transition-colors">
                  Owner Dashboard
                </Link>
              </li>
              <li>
                <Link href="/faq" className="hover:text-white transition-colors">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-display font-semibold text-white text-lg mb-4">
              Contact Us
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <FiMapPin className="w-5 h-5 mt-1 flex-shrink-0 text-ocean-400" />
                <span>Colombo, Sri Lanka</span>
              </li>
              <li className="flex items-start gap-3">
                <FiMail className="w-5 h-5 mt-1 flex-shrink-0 text-ocean-400" />
                <a href="mailto:support@annexfinder.lk" className="hover:text-white transition-colors">
                  support@annexfinder.lk
                </a>
              </li>
              <li className="flex items-start gap-3">
                <FiPhone className="w-5 h-5 mt-1 flex-shrink-0 text-ocean-400" />
                <a href="tel:+94770000000" className="hover:text-white transition-colors">
                  +94 77 000 0000
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-stone-800">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-stone-500 text-sm">
              © {currentYear} AnnexFinder. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <Link href="/privacy" className="hover:text-white transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="hover:text-white transition-colors">
                Terms of Service
              </Link>
              <Link href="/contact" className="hover:text-white transition-colors">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
