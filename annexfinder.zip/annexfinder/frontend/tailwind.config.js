/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // Modern Sri Lankan color palette
        ocean: {
          50: '#E6F3F8',
          100: '#CCE8F1',
          200: '#99D0E3',
          300: '#66B9D5',
          400: '#33A1C7',
          500: '#008AB9', // Primary ocean blue
          600: '#006E94',
          700: '#00536F',
          800: '#00374A',
          900: '#001C25',
        },
        sunset: {
          50: '#FFF5E6',
          100: '#FFEBCC',
          200: '#FFD699',
          300: '#FFC266',
          400: '#FFAD33',
          500: '#FF9900', // Warm sunset orange
          600: '#CC7A00',
          700: '#995C00',
          800: '#663D00',
          900: '#331F00',
        },
        copper: {
          50: '#FAF5F0',
          100: '#F5EBE1',
          200: '#EBD7C3',
          300: '#E1C3A5',
          400: '#D7AF87',
          500: '#CD9B69', // Traditional copper/gold
          600: '#A47C54',
          700: '#7B5D3F',
          800: '#523E2A',
          900: '#291F15',
        },
        stone: {
          50: '#F9FAFB',
          100: '#F3F4F6',
          200: '#E5E7EB',
          300: '#D1D5DB',
          400: '#9CA3AF',
          500: '#6B7280',
          600: '#4B5563',
          700: '#374151',
          800: '#1F2937',
          900: '#111827',
        }
      },
      fontFamily: {
        display: ['var(--font-bricolage)', 'system-ui', 'sans-serif'],
        body: ['var(--font-inter)', 'system-ui', 'sans-serif'],
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
        'sri-lanka-pattern': "url('/patterns/sri-lanka-subtle.svg')",
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease-out',
        'slide-up': 'slideUp 0.5s ease-out',
        'slide-down': 'slideDown 0.5s ease-out',
        'scale-in': 'scaleIn 0.4s ease-out',
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideDown: {
          '0%': { transform: 'translateY(-20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        scaleIn: {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
      boxShadow: {
        'soft': '0 2px 20px rgba(0, 138, 185, 0.08)',
        'soft-lg': '0 4px 40px rgba(0, 138, 185, 0.12)',
        'glow': '0 0 20px rgba(255, 153, 0, 0.3)',
      },
    },
  },
  plugins: [],
}
