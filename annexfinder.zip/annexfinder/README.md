# 🏠 AnnexFinder - Student & Professional Housing Platform

**Full-stack property marketplace for Sri Lanka with geo-spatial search, real-time messaging, and payment integration**

Built with PostgreSQL + PostGIS, Node.js + Express, and Next.js 14

## 📋 Project Overview

AnnexFinder connects students and working professionals with property owners across Sri Lanka through intelligent geo-spatial search. Users search by university name or workplace address, and the platform shows nearby properties ranked by actual walking distance using PostGIS geography calculations.

### ✨ Key Features

**For Tenants:**
- Geo-search near universities/workplaces
- Distance-based results with walking time estimates
- Save & compare properties
- Direct messaging with owners
- Smart filters (price, type, amenities)

**For Property Owners:**
- 3-tier subscription model (Free/Standard/Premium)
- Complete listing management
- Analytics dashboard with conversion tracking
- Listing boost (featured placement)
- Centralized enquiry inbox

**For Administrators:**
- Auto-scored listing approval workflow
- User management & moderation
- Fraud/abuse reporting system
- Platform-wide analytics (MRR, conversion funnels)

## 🏗️ Technology Stack

### Backend
- **Node.js + Express** - RESTful API server
- **PostgreSQL 15** - Relational database
- **PostGIS** - Spatial queries and distance calculations
- **JWT** - Authentication
- **PayHere** - Sri Lankan payment gateway
- **Cloudinary** - Image hosting

### Frontend
- **Next.js 14** - React framework (App Router)
- **Tailwind CSS** - Utility-first styling
- **Leaflet.js** - Interactive maps
- **Axios** - API communication
- **Framer Motion** - Animations

### Design System
**"Modern Sri Lankan Minimalism"**
- Ocean Blue (#008AB9) - Primary
- Sunset Orange (#FF9900) - Accents
- Copper Gold (#CD9B69) - Premium
- Bricolage Grotesque + Inter fonts

## 📂 Project Structure

```
annexfinder/
├── backend/
│   ├── config/
│   │   └── database.js          # PostgreSQL connection pool
│   ├── middleware/
│   │   ├── auth.js              # JWT authentication
│   │   └── errorHandler.js      # Centralized error handling
│   ├── routes/
│   │   ├── auth.js              # Register, login, password reset
│   │   ├── search.js            # Geo-search endpoints
│   │   ├── listings.js          # Property CRUD
│   │   ├── enquiries.js         # Messaging system
│   │   ├── owner.js             # Owner dashboard & analytics
│   │   ├── admin.js             # Admin panel endpoints
│   │   └── payments.js          # PayHere integration
│   ├── package.json
│   └── server.js                # Express server with cron jobs
├── frontend/
│   ├── app/
│   │   ├── layout.tsx           # Root layout with fonts
│   │   ├── page.tsx             # Home page with dual-search
│   │   └── globals.css          # Design system styles
│   ├── lib/
│   │   └── api.ts               # Backend API client
│   ├── package.json
│   └── tailwind.config.js       # Custom design tokens
├── database/
│   ├── schema.sql               # Complete DB schema with PostGIS
│   └── queries.sql              # Spatial query functions
├── .env.example                 # Environment template
└── README.md                    # This file
```

## 🚀 Setup Instructions

### Prerequisites

- Node.js 18+
- PostgreSQL 15+ with PostGIS
- npm or yarn

### 1. Database Setup

```bash
# Install PostgreSQL and PostGIS
sudo apt-get install postgresql-15 postgresql-15-postgis-3

# Create database
createdb annexfinder

# Run schema (creates tables, indexes, triggers)
psql annexfinder < database/schema.sql

# Run spatial query functions
psql annexfinder < database/queries.sql
```

The schema includes:
- 15 pre-seeded Sri Lankan universities
- Complete spatial indexes for fast geo-queries
- Auto-triggers for location sync and timestamps

### 2. Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Copy and configure environment
cp ../.env.example .env

# Edit .env with your values:
# - Database credentials
# - JWT secret
# - PayHere keys
# - Cloudinary credentials

# Start development server
npm run dev
```

API runs on **http://localhost:5000**

### 3. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Configure environment
cp ../.env.example .env

# Edit NEXT_PUBLIC_API_URL and other vars

# Start development server
npm run dev
```

Frontend runs on **http://localhost:3000**

## 🗄️ Database Schema Highlights

### PostGIS Geography Type

```sql
-- Properties table uses GEOGRAPHY for accurate distance calculations
ALTER TABLE properties
ADD COLUMN location geography(Point, 4326);

-- Auto-sync trigger keeps location column in sync with lat/lng
CREATE TRIGGER sync_properties_location 
BEFORE INSERT OR UPDATE ON properties
FOR EACH ROW EXECUTE FUNCTION sync_location_column();
```

### Key Tables

- **users** - Tenants, owners, admins with role enum
- **properties** - Listings with PostGIS location column
- **universities** - Pre-seeded with coordinates
- **enquiries** - Conversation threads
- **messages** - Individual messages
- **subscriptions** - Owner plans (free/standard/premium)
- **boosts** - Active listing promotions
- **property_views** - Analytics (deduplicated by IP + date)

### Spatial Queries

```sql
-- University proximity search
SELECT * FROM search_by_university(
  'University of Colombo',  -- university name
  3000,                      -- radius metres
  NULL,                      -- min_rent
  NULL,                      -- max_rent
  NULL,                      -- property_type
  NULL,                      -- furnished
  NULL,                      -- bedrooms
  50                         -- limit
);

-- Returns properties with distance_metres and distance_label
-- Sorted by: boosted first, then closest
```

## 🔐 API Authentication

JWT-based with 7-day expiry. Middleware checks token and user status.

```javascript
// Example authenticated request
const response = await fetch('http://localhost:5000/api/owner/stats', {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
});
```

### Role-Based Access

- **Public**: Search, property detail, featured listings
- **Tenant**: Enquiries, saved listings, profile
- **Owner**: Create listings, analytics, billing
- **Admin**: Approve listings, manage users, platform stats

## 💳 Payment Integration (PayHere)

### Subscription Flow

1. Owner selects plan (Standard LKR 2,500 or Premium LKR 6,000)
2. Backend creates pending payment record
3. Frontend redirects to PayHere checkout
4. PayHere sends webhook to `/api/payments/webhook`
5. Backend **verifies MD5 signature** (critical security step)
6. On valid signature: activate subscription, update listings
7. Send confirmation email

### Webhook Verification

```javascript
// CRITICAL: Always verify signature
const crypto = require('crypto');

function verifyPayHereSignature(payload) {
  const secretHash = crypto
    .createHash('md5')
    .update(merchantSecret)
    .digest('hex')
    .toUpperCase();
    
  const raw = merchant_id + order_id + amount + currency + status + secretHash;
  
  const expected = crypto
    .createHash('md5')
    .update(raw)
    .digest('hex')
    .toUpperCase();
    
  return expected === payload.md5sig;
}
```

Never activate subscriptions from redirect URLs alone - always verify webhooks.

## 📡 Core API Endpoints

### Search & Listings

```
GET  /api/search?uni=University+of+Colombo&radius=3000
GET  /api/search?lat=6.9271&lng=79.8612&radius=3000
GET  /api/search/universities?q=colombo
GET  /api/search/featured
GET  /api/listings/:id
```

### Authentication

```
POST /api/auth/register
POST /api/auth/login
POST /api/auth/forgot-password
POST /api/auth/reset-password
```

### Enquiries (Authenticated)

```
POST   /api/enquiries
GET    /api/enquiries
GET    /api/enquiries/:id/messages
POST   /api/enquiries/:id/messages
PATCH  /api/enquiries/:id/status
```

### Owner (Authenticated)

```
GET    /api/owner/stats
GET    /api/owner/analytics?period=30d
GET    /api/owner/listings
POST   /api/listings
PATCH  /api/listings/:id
DELETE /api/listings/:id
```

### Payments (Authenticated)

```
POST /api/payments/subscription/checkout
POST /api/payments/boost/checkout
POST /api/payments/webhook        # PayHere webhook
GET  /api/payments/history
```

### Admin (Authenticated)

```
GET   /api/admin/listings?status=pending
PATCH /api/admin/listings/:id/approve
PATCH /api/admin/listings/:id/reject
GET   /api/admin/users
PATCH /api/admin/users/:id/suspend
GET   /api/admin/stats
```

## 🎨 Frontend Design System

### Custom Tailwind Classes

```css
/* Buttons */
.btn-primary     /* Ocean blue with shadow */
.btn-secondary   /* White with ocean border */
.btn-accent      /* Sunset orange with glow */

/* Cards */
.card            /* Rounded-2xl with soft shadow */
.card-interactive /* Hover scale effect */

/* Badges */
.badge-verified  /* Ocean-tinted verified badge */
.badge-boosted   /* Sunset-tinted featured badge */
.distance-badge  /* Distance labels with icon */

/* Inputs */
.input           /* Focus ring with ocean accent */

/* Layout */
.section         /* Consistent vertical spacing */
.container-custom /* Max-width with responsive padding */
```

### Color Palette

```javascript
// tailwind.config.js
colors: {
  ocean: {
    500: '#008AB9',  // Primary
    600: '#006E94',
  },
  sunset: {
    500: '#FF9900',  // Accent
    600: '#CC7A00',
  },
  copper: {
    500: '#CD9B69',  // Premium
  },
  stone: {
    // Neutral grays
  }
}
```

## 🔄 Cron Jobs (Production)

Schedule these in production environment:

```bash
# Daily at 1 AM - Expire subscriptions
SELECT expire_subscriptions();
# Pauses listings from expired plans

# Hourly - Remove expired boosts
SELECT remove_expired_boosts();

# Daily at 2 AM - Deduplicate views
SELECT deduplicate_property_views();
# Keeps analytics clean (IP + date dedup)
```

## 📊 Subscription Tiers

| Plan | Price | Listings | Features |
|------|-------|----------|----------|
| Free | LKR 0 | 1 active | Basic enquiries, 5 photos |
| Standard | LKR 2,500/mo | 3 active | Verified badge, priority search, 10 photos |
| Premium | LKR 6,000/mo | Unlimited | Featured placement, analytics, support |

**Additional Revenue:**
- Listing Boost: LKR 500 (7 days) or LKR 900 (14 days)
- High visibility in search results

## 🚀 Production Deployment

### Database
- **Railway**, **Supabase**, or **AWS RDS**
- Enable PostGIS extension
- Run migrations from `/database`

### Backend
- **Railway**, **Render**, or **Vercel Serverless**
- Set all environment variables
- Enable CORS for frontend domain

### Frontend
- **Vercel** (zero-config Next.js)
- Set `NEXT_PUBLIC_API_URL` to backend URL
- Build command: `npm run build`

### Environment Checklist

```bash
✅ Database credentials
✅ JWT_SECRET (long random string)
✅ PayHere merchant credentials
✅ Cloudinary keys
✅ Google Maps API key
✅ Email provider (SendGrid)
✅ CORS domains
```

## 📈 Roadmap

### Phase 1 - MVP ✅
- [x] Geo-spatial search with PostGIS
- [x] Property listings & photos
- [x] Enquiry messaging system
- [x] Owner dashboard & analytics
- [x] Admin approval workflow
- [x] PayHere payment integration

### Phase 2 - Growth
- [ ] Saved search alerts (email on new matches)
- [ ] Review & rating system
- [ ] Tenant premium plan
- [ ] SMS notifications (Notify.lk)
- [ ] University partnership pages

### Phase 3 - Scale
- [ ] Mobile apps (React Native)
- [ ] Virtual property tours
- [ ] ML-powered recommendations
- [ ] Multi-language support (Sinhala, Tamil)

## 🐛 Known Issues / TODOs

- [ ] Google OAuth implementation incomplete
- [ ] Email sending (SendGrid integration stub)
- [ ] SMS notifications (Notify.lk integration stub)
- [ ] Image upload to Cloudinary (needs multer setup)
- [ ] Unit tests for API endpoints
- [ ] E2E tests for critical flows

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes with clear messages
4. Push to branch
5. Open Pull Request

## 📝 License

Copyright © 2026 AnnexFinder. All rights reserved.

## 🆘 Support

**Questions or issues?**
- Email: support@annexfinder.lk
- Create GitHub issue
- Check `/docs` folder for detailed guides

---

**Built with ❤️ in Sri Lanka**

*Finding homes, building communities*
