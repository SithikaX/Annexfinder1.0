# 🚀 Getting Started with AnnexFinder

**Welcome! Let's get your property marketplace running in 15 minutes.**

## ⚡ Quick Setup (3 Commands)

```bash
# 1. Run automated setup
cd annexfinder
chmod +x setup.sh
./setup.sh

# 2. Configure (5 minutes)
# Edit these two files with your credentials:
nano backend/.env
nano frontend/.env

# 3. Start both servers
# Terminal 1:
cd backend && npm run dev

# Terminal 2:
cd frontend && npm run dev
```

✅ **Done!** Open http://localhost:3000

---

## 📝 Step-by-Step Guide

### Step 1: Prerequisites

Make sure you have these installed:

```bash
# Check Node.js (need 18+)
node --version

# Check PostgreSQL (need 15+)
psql --version

# Install PostGIS if needed
sudo apt-get install postgresql-15-postgis-3
# OR on Mac:
brew install postgis
```

### Step 2: Database Setup

```bash
# Create database
createdb annexfinder

# Run schema (creates all tables)
psql annexfinder < database/schema.sql

# Run spatial queries (adds PostGIS functions)
psql annexfinder < database/queries.sql

# Verify it worked
psql annexfinder -c "SELECT COUNT(*) FROM universities;"
# Should return 15
```

### Step 3: Backend Configuration

```bash
cd backend

# Install dependencies
npm install

# Create environment file
cp ../.env.example .env
```

**Edit `backend/.env`:**

```bash
# Required - Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=annexfinder
DB_USER=postgres
DB_PASSWORD=YOUR_PASSWORD_HERE  # ← Change this

# Required - Security
JWT_SECRET=your-super-long-random-secret-key-change-this-in-production  # ← Change this

# Required for payments - Get from PayHere
PAYHERE_MERCHANT_ID=your_merchant_id
PAYHERE_MERCHANT_SECRET=your_merchant_secret
PAYHERE_MODE=sandbox  # Use 'live' in production

# Optional (can add later)
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

SENDGRID_API_KEY=your_sendgrid_key
FROM_EMAIL=no-reply@annexfinder.lk
```

**Test the backend:**

```bash
npm run dev

# Should see:
# ╔═══════════════════════════════════════════════╗
# ║         AnnexFinder API Server                ║
# ║         Running on port 5000                  ║
# ╚═══════════════════════════════════════════════╝
```

### Step 4: Frontend Configuration

```bash
cd frontend

# Install dependencies
npm install

# Create environment file
cp ../.env.example .env
```

**Edit `frontend/.env`:**

```bash
# Point to your backend
NEXT_PUBLIC_API_URL=http://localhost:5000

# Get free key from Google Cloud Console
NEXT_PUBLIC_GOOGLE_MAPS_KEY=your_google_maps_api_key

# Your domain (for production)
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

**Start the frontend:**

```bash
npm run dev

# Should see:
# ▲ Next.js 14.0.4
# - Local:        http://localhost:3000
# - Ready in 2.5s
```

### Step 5: Test It Works

Open **http://localhost:3000** in your browser.

You should see:
- ✅ Beautiful home page with gradient background
- ✅ Dual-mode search (University / Workplace)
- ✅ Trust indicators (2,400+ properties)
- ✅ How it works section

**Test the API:**

```bash
# In a new terminal:
curl http://localhost:5000/health

# Should return:
# {"status":"ok","timestamp":"...","service":"AnnexFinder API"}
```

---

## 🎯 Next Steps - Build the Platform

### Immediate (Complete the MVP)

#### 1. Create Test User

```bash
# Using curl or Postman
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "owner@test.com",
    "password": "test1234",
    "name": "Test Owner",
    "role": "owner",
    "phone": "0771234567"
  }'

# Save the returned token
```

#### 2. Add Your First Property

```bash
curl -X POST http://localhost:5000/api/listings \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "title": "Cozy Annex Near University of Colombo",
    "description": "Beautiful 2-bedroom annex just 10 minutes walk from University of Colombo main campus. Fully furnished with WiFi, hot water, and parking. Perfect for students or working professionals.",
    "address": "123 Wijerama Mawatha, Colombo 07",
    "city": "Colombo",
    "lat": 6.9022,
    "lng": 79.8607,
    "rent_lkr": 35000,
    "property_type": "annex",
    "furnished": "furnished",
    "bedrooms": 2,
    "bathrooms": 1,
    "amenities": ["wifi", "water", "parking", "generator"],
    "available_from": "2026-05-01",
    "target_audience": "both"
  }'
```

#### 3. Build Frontend Pages

**Priority order:**

1. **Search Results Page** (`app/search/page.tsx`)
   - Map view with property pins
   - List view with cards
   - Filters sidebar
   - Use `/api/search` endpoint

2. **Property Detail Page** (`app/property/[id]/page.tsx`)
   - Photo gallery
   - Key details
   - Distance map
   - Enquiry form
   - Use `/api/listings/:id` endpoint

3. **Owner Dashboard** (`app/owner/dashboard/page.tsx`)
   - Metric cards (views, enquiries)
   - Recent enquiries feed
   - Listing status overview
   - Use `/api/owner/stats` endpoint

4. **Login/Register Pages** (`app/login/page.tsx`, `app/register/page.tsx`)
   - Email + password forms
   - Role selection
   - Use `/api/auth/login` and `/api/auth/register`

**Component structure already created:**
- ✅ `components/Navbar.tsx` - Navigation
- ✅ `components/Footer.tsx` - Footer
- ✅ `components/PropertyMap.tsx` - Leaflet map
- You need to add: PropertyCard, SearchFilters, PhotoGallery, EnquiryModal

### Short-Term (Polish & Launch)

#### 1. Image Upload

```bash
# Install multer for file uploads
cd backend
npm install multer

# Add Cloudinary credentials to .env
# Implement in backend/routes/listings.js
```

#### 2. Email Notifications

```bash
# Install SendGrid
npm install @sendgrid/mail

# Add templates:
# - New enquiry (to owner)
# - Owner replied (to tenant)
# - Listing approved/rejected
# - Subscription expiring
```

#### 3. Payment Testing

```bash
# Get PayHere sandbox credentials from:
# https://www.payhere.lk/downloads/

# Test subscription flow:
1. Create owner account
2. Try to add 2nd listing (should hit limit)
3. Purchase Standard plan (LKR 2,500)
4. Verify webhook receives payment
5. Check subscription activated
```

---

## 🐛 Troubleshooting

### Database connection fails

```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Check credentials
psql -h localhost -U postgres -d annexfinder

# Verify PostGIS installed
psql annexfinder -c "SELECT PostGIS_Version();"
```

### Backend won't start

```bash
# Check Node version (need 18+)
node --version

# Install dependencies again
cd backend
rm -rf node_modules package-lock.json
npm install

# Check .env file exists
cat .env

# Check logs
npm run dev 2>&1 | tee backend.log
```

### Frontend build errors

```bash
# Clear Next.js cache
cd frontend
rm -rf .next

# Reinstall
rm -rf node_modules package-lock.json
npm install

# Try again
npm run dev
```

### "Cannot find module" errors

```bash
# Make sure you're in the right directory
pwd  # Should show .../annexfinder/backend or .../annexfinder/frontend

# Verify package.json exists
ls -la package.json
```

---

## 📚 Understanding the Code

### Backend Architecture

```
backend/
├── server.js           # Express app + cron jobs
├── config/
│   └── database.js     # PostgreSQL connection pool
├── middleware/
│   ├── auth.js         # JWT authentication
│   └── errorHandler.js # Centralized error handling
└── routes/
    ├── auth.js         # Register, login, password reset
    ├── search.js       # PostGIS geo-search
    ├── listings.js     # Property CRUD
    ├── enquiries.js    # Messaging
    ├── owner.js        # Dashboard, analytics
    ├── admin.js        # Approval workflow
    └── payments.js     # PayHere integration
```

**Key concepts:**

- **JWT Authentication**: Token in `Authorization: Bearer` header
- **Role-Based Access**: Middleware checks user.role
- **PostGIS Queries**: Functions in `database/queries.sql`
- **Transactions**: Used for multi-step operations (payment + subscription)

### Database Schema

```
Key tables:
- users (tenants, owners, admins)
- properties (with PostGIS location column)
- universities (pre-seeded with coordinates)
- enquiries + messages (conversation threads)
- subscriptions (owner plans)
- boosts (featured listings)
```

**Important:**
- `location` column uses **geography** type (not geometry)
- This gives accurate distances on Earth's curved surface
- All spatial queries use `ST_Distance` and `ST_DWithin`

### Frontend Structure

```
frontend/
├── app/
│   ├── layout.tsx      # Root layout with fonts
│   ├── page.tsx        # Home page
│   └── globals.css     # Design system
├── components/
│   ├── Navbar.tsx      # Navigation
│   ├── Footer.tsx      # Footer
│   └── PropertyMap.tsx # Leaflet map
└── lib/
    └── api.ts          # API client
```

---

## 🎨 Design System Reference

### Colors

```css
ocean-500:  #008AB9  /* Primary buttons, links */
ocean-600:  #006E94  /* Hover states */
sunset-500: #FF9900  /* Accents, CTAs */
copper-500: #CD9B69  /* Premium features */
stone-500:  #6B7280  /* Text */
stone-100:  #F3F4F6  /* Backgrounds */
```

### Components

```tsx
<button className="btn-primary">Primary Action</button>
<button className="btn-secondary">Secondary</button>
<button className="btn-accent">Accent CTA</button>

<div className="card">Card content</div>
<div className="card-interactive">Clickable card</div>

<input className="input" />

<span className="badge-verified">Verified</span>
<span className="badge-boosted">Featured</span>
<span className="distance-badge">15 min walk</span>
```

---

## 🚀 Deployment Checklist

Before going live:

- [ ] Change JWT_SECRET to long random string
- [ ] Switch PayHere to live mode
- [ ] Set up Cloudinary for image hosting
- [ ] Configure SendGrid email templates
- [ ] Set up domain (annexfinder.lk)
- [ ] Deploy database to Railway/Supabase
- [ ] Deploy backend to Railway/Render
- [ ] Deploy frontend to Vercel
- [ ] Set up SSL certificates (automatic on Vercel/Railway)
- [ ] Configure cron jobs for subscriptions
- [ ] Set up monitoring (Sentry)
- [ ] Test complete user flows

See `DEPLOYMENT.md` for detailed production deployment guide.

---

## 🎯 Success Metrics

You'll know it's working when:

✅ Users can search for properties near universities
✅ Distance calculations show accurate walking times
✅ Enquiry messages send successfully
✅ PayHere webhooks activate subscriptions
✅ Admin can approve/reject listings
✅ Owner sees analytics dashboard
✅ Boosted listings appear first in search

---

## 🆘 Need Help?

**Check these first:**
1. `README.md` - Complete platform overview
2. `DEPLOYMENT.md` - Production deployment
3. Code comments - Every file is documented
4. Console logs - Backend logs all queries

**Common issues:**
- "Database connection refused" → Check PostgreSQL running
- "Token invalid" → Check JWT_SECRET set
- "PostGIS function not found" → Run database/queries.sql
- "Port already in use" → Kill process on 5000 or 3000

---

## 🎉 You're Ready!

You now have:
- ✅ Complete backend with 27 API endpoints
- ✅ PostgreSQL database with PostGIS
- ✅ Frontend foundation with design system
- ✅ Payment integration ready
- ✅ Complete documentation

**Next: Build the frontend pages and launch!** 🚀

Good luck! 🏠
