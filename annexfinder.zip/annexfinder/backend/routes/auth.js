// Authentication routes
const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const { body, validationResult } = require('express-validator');
const db = require('../config/database');
const { generateToken } = require('../middleware/auth');
const crypto = require('crypto');

// Validation middleware
const validateRegistration = [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }),
  body('name').trim().isLength({ min: 2, max: 150 }),
  body('role').isIn(['tenant', 'owner']),
  body('phone').optional().matches(/^[0-9]{10}$/)
];

const validateLogin = [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty()
];

// POST /api/auth/register - Create new account
router.post('/register', validateRegistration, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
    }

    const { email, password, name, role, phone } = req.body;

    // Check if email exists
    const existing = await db.query(
      'SELECT id FROM users WHERE email = $1',
      [email]
    );

    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);

    // Generate verification token
    const verificationToken = crypto.randomBytes(32).toString('hex');

    // Insert user
    const result = await db.query(
      `INSERT INTO users (email, password_hash, name, role, phone, verification_token)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, email, name, role, email_verified, created_at`,
      [email, passwordHash, name, role, phone, verificationToken]
    );

    const user = result.rows[0];

    // Generate JWT
    const token = generateToken(user.id, user.role);

    // TODO: Send verification email with token
    // await sendVerificationEmail(email, verificationToken);

    res.status(201).json({
      message: 'Registration successful',
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        emailVerified: user.email_verified
      },
      token
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/auth/login - Authenticate user
router.post('/login', validateLogin, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
    }

    const { email, password } = req.body;

    // Get user with password hash
    const result = await db.query(
      `SELECT id, email, password_hash, name, role, is_suspended, email_verified
       FROM users 
       WHERE email = $1`,
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = result.rows[0];

    // Check if suspended
    if (user.is_suspended) {
      return res.status(403).json({ error: 'Account suspended' });
    }

    // Verify password
    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate JWT
    const token = generateToken(user.id, user.role);

    res.json({
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        emailVerified: user.email_verified
      },
      token
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/auth/google - OAuth login
router.post('/google', async (req, res, next) => {
  try {
    const { idToken, role } = req.body;

    // TODO: Verify Google ID token with Google OAuth API
    // For now, this is a placeholder
    // const googleUser = await verifyGoogleToken(idToken);

    res.status(501).json({ 
      error: 'Google OAuth not yet implemented',
      message: 'Use email/password authentication'
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/auth/verify-email - Verify email with token
router.post('/verify-email', async (req, res, next) => {
  try {
    const { token } = req.body;

    const result = await db.query(
      `UPDATE users 
       SET email_verified = TRUE, verification_token = NULL
       WHERE verification_token = $1
       RETURNING id, email, name`,
      [token]
    );

    if (result.rows.length === 0) {
      return res.status(400).json({ error: 'Invalid or expired token' });
    }

    res.json({
      message: 'Email verified successfully',
      user: result.rows[0]
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/auth/forgot-password - Request password reset
router.post('/forgot-password', async (req, res, next) => {
  try {
    const { email } = req.body;

    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetExpires = new Date(Date.now() + 3600000); // 1 hour

    const result = await db.query(
      `UPDATE users 
       SET reset_token = $1, reset_token_expires = $2
       WHERE email = $3
       RETURNING id, email, name`,
      [resetToken, resetExpires, email]
    );

    if (result.rows.length === 0) {
      // Don't reveal if email exists
      return res.json({ message: 'If that email exists, a reset link has been sent' });
    }

    // TODO: Send password reset email
    // await sendPasswordResetEmail(email, resetToken);

    res.json({ message: 'Password reset email sent' });
  } catch (error) {
    next(error);
  }
});

// POST /api/auth/reset-password - Reset password with token
router.post('/reset-password', async (req, res, next) => {
  try {
    const { token, newPassword } = req.body;

    if (newPassword.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters' });
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);

    const result = await db.query(
      `UPDATE users 
       SET password_hash = $1, reset_token = NULL, reset_token_expires = NULL
       WHERE reset_token = $2 AND reset_token_expires > NOW()
       RETURNING id`,
      [passwordHash, token]
    );

    if (result.rows.length === 0) {
      return res.status(400).json({ error: 'Invalid or expired reset token' });
    }

    res.json({ message: 'Password reset successful' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
