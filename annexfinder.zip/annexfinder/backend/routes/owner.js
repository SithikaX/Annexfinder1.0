// Owner routes - Dashboard, analytics, and management
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { requireAuth, requireRole } = require('../middleware/auth');

// All routes require owner role
router.use(requireAuth, requireRole('owner'));

// GET /api/owner/stats - Dashboard summary
router.get('/stats', async (req, res, next) => {
  try {
    const userId = req.user.id;

    // Get subscription info
    const subResult = await db.query(
      `SELECT plan, expires_at, is_active
       FROM subscriptions
       WHERE user_id = $1 AND is_active = TRUE
       ORDER BY created_at DESC
       LIMIT 1`,
      [userId]
    );

    const subscription = subResult.rows[0] || { plan: 'free', is_active: false };

    // Get listing counts by status
    const statusResult = await db.query(
      `SELECT status, COUNT(*) as count
       FROM properties
       WHERE owner_id = $1
       GROUP BY status`,
      [userId]
    );

    const statusCounts = {
      active: 0,
      pending: 0,
      paused: 0,
      rented: 0
    };

    statusResult.rows.forEach(row => {
      statusCounts[row.status] = parseInt(row.count);
    });

    // Get recent enquiries (last 5)
    const enquiriesResult = await db.query(
      `SELECT 
        e.id, e.status, e.created_at,
        p.title as property_title,
        u.name as tenant_name,
        (SELECT content FROM messages WHERE enquiry_id = e.id ORDER BY created_at DESC LIMIT 1) as last_message
       FROM enquiries e
       JOIN properties p ON p.id = e.property_id
       JOIN users u ON u.id = e.tenant_id
       WHERE p.owner_id = $1
       ORDER BY e.last_message_at DESC
       LIMIT 5`,
      [userId]
    );

    // Get 30-day totals
    const totalsResult = await db.query(
      `SELECT 
        COUNT(DISTINCT v.id) as total_views,
        COUNT(DISTINCT e.id) as total_enquiries,
        COUNT(DISTINCT s.id) as total_saves
       FROM properties p
       LEFT JOIN property_views v ON v.property_id = p.id AND v.viewed_at >= NOW() - INTERVAL '30 days'
       LEFT JOIN enquiries e ON e.property_id = p.id AND e.created_at >= NOW() - INTERVAL '30 days'
       LEFT JOIN saved_listings s ON s.property_id = p.id AND s.saved_at >= NOW() - INTERVAL '30 days'
       WHERE p.owner_id = $1`,
      [userId]
    );

    const totals = totalsResult.rows[0];

    res.json({
      subscription,
      listing_counts: statusCounts,
      recent_enquiries: enquiriesResult.rows,
      totals: {
        views: parseInt(totals.total_views) || 0,
        enquiries: parseInt(totals.total_enquiries) || 0,
        saves: parseInt(totals.total_saves) || 0,
        enquiry_rate: totals.total_views > 0 
          ? ((parseInt(totals.total_enquiries) / parseInt(totals.total_views)) * 100).toFixed(1)
          : 0
      }
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/owner/analytics - Detailed analytics
router.get('/analytics', async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { period = '30d' } = req.query;

    // Parse period
    const days = period === '7d' ? 7 : period === '90d' ? 90 : 30;

    // Get per-listing analytics
    const analyticsResult = await db.query(
      'SELECT * FROM get_owner_analytics($1, $2)',
      [userId, days]
    );

    // Get trend data (daily breakdown)
    const trendResult = await db.query(
      `SELECT 
        DATE(v.viewed_at) as date,
        COUNT(DISTINCT v.id) as views,
        COUNT(DISTINCT e.id) as enquiries
       FROM properties p
       LEFT JOIN property_views v ON v.property_id = p.id 
         AND v.viewed_at >= NOW() - INTERVAL '${days} days'
       LEFT JOIN enquiries e ON e.property_id = p.id 
         AND e.created_at >= NOW() - INTERVAL '${days} days'
       WHERE p.owner_id = $1
       GROUP BY DATE(v.viewed_at)
       ORDER BY date ASC`,
      [userId]
    );

    res.json({
      period,
      by_listing: analyticsResult.rows,
      trend: trendResult.rows
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/owner/listings - Get all owner's listings
router.get('/listings', async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { status } = req.query;

    let query = `
      SELECT 
        p.id, p.title, p.rent_lkr, p.property_type, p.status,
        p.view_count, p.enquiry_count, p.created_at,
        (SELECT url FROM property_photos WHERE property_id = p.id AND is_primary = TRUE LIMIT 1) as photo_url,
        CASE WHEN b.id IS NOT NULL THEN TRUE ELSE FALSE END as is_boosted,
        b.expires_at as boost_expires_at
      FROM properties p
      LEFT JOIN boosts b ON b.property_id = p.id AND b.expires_at > NOW()
      WHERE p.owner_id = $1
    `;

    const params = [userId];

    if (status) {
      query += ' AND p.status = $2';
      params.push(status);
    }

    query += ' ORDER BY p.created_at DESC';

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

// POST /api/owner/saved-searches - Save a search (Phase 2)
router.post('/saved-searches', async (req, res, next) => {
  try {
    // Placeholder for future feature
    res.status(501).json({ 
      message: 'Saved searches coming in Phase 2' 
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
