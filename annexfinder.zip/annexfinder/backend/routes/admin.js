// Admin routes - Platform management and moderation
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { requireAuth, requireRole } = require('../middleware/auth');

// All routes require admin role
router.use(requireAuth, requireRole('admin'));

// GET /api/admin/listings - Review queue
router.get('/listings', async (req, res, next) => {
  try {
    const { status = 'pending', page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const result = await db.query(
      `SELECT 
        p.*,
        u.name as owner_name, u.email as owner_email,
        (SELECT COUNT(*) FROM property_photos WHERE property_id = p.id) as photo_count,
        (SELECT COUNT(*) FROM reports WHERE property_id = p.id AND status = 'open') as report_count,
        (SELECT url FROM property_photos WHERE property_id = p.id AND is_primary = TRUE LIMIT 1) as primary_photo,
        ARRAY_AGG(ph.url) as all_photos
       FROM properties p
       JOIN users u ON u.id = p.owner_id
       LEFT JOIN property_photos ph ON ph.property_id = p.id
       WHERE p.status = $1
       GROUP BY p.id, u.name, u.email
       ORDER BY p.created_at ASC
       LIMIT $2 OFFSET $3`,
      [status, limit, offset]
    );

    // Auto-score each listing
    const scoredListings = result.rows.map(listing => {
      const checks = {
        has_photos: listing.photo_count >= 3,
        has_address: !!listing.address && listing.lat && listing.lng,
        has_rent: listing.rent_lkr > 0,
        has_details: !!listing.property_type && listing.bedrooms !== null,
        has_description: listing.description && listing.description.length >= 80,
        no_duplicates: true // Would need spatial check
      };

      const passed = Object.values(checks).filter(Boolean).length;
      const total = Object.keys(checks).length;

      return {
        ...listing,
        auto_checks: checks,
        auto_score: `${passed}/${total}`
      };
    });

    res.json({
      listings: scoredListings,
      page: parseInt(page),
      limit: parseInt(limit)
    });
  } catch (error) {
    next(error);
  }
});

// PATCH /api/admin/listings/:id/approve - Approve listing
router.patch('/listings/:id/approve', async (req, res, next) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `UPDATE properties 
       SET status = 'active', is_verified = TRUE, updated_at = NOW()
       WHERE id = $1 AND status = 'pending'
       RETURNING id, title, owner_id`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Listing not found or not pending' });
    }

    const listing = result.rows[0];

    // TODO: Send approval email to owner
    // await sendListingApprovedEmail(listing.owner_id, listing.title);

    res.json({
      message: 'Listing approved',
      listing_id: listing.id
    });
  } catch (error) {
    next(error);
  }
});

// PATCH /api/admin/listings/:id/reject - Reject listing
router.patch('/listings/:id/reject', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    if (!reason || reason.length < 20) {
      return res.status(400).json({ 
        error: 'Rejection reason required (min 20 characters)' 
      });
    }

    const result = await db.query(
      `UPDATE properties 
       SET status = 'rejected', rejection_reason = $2, updated_at = NOW()
       WHERE id = $1 AND status = 'pending'
       RETURNING id, title, owner_id`,
      [id, reason]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Listing not found or not pending' });
    }

    const listing = result.rows[0];

    // TODO: Send rejection email with reason
    // await sendListingRejectedEmail(listing.owner_id, listing.title, reason);

    res.json({
      message: 'Listing rejected',
      listing_id: listing.id
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/admin/users - User management
router.get('/users', async (req, res, next) => {
  try {
    const { q, role, suspended, page = 1, limit = 50 } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT 
        u.id, u.email, u.name, u.role, u.phone,
        u.is_suspended, u.email_verified, u.created_at,
        s.plan, s.expires_at,
        COUNT(p.id) as listing_count
      FROM users u
      LEFT JOIN subscriptions s ON s.user_id = u.id AND s.is_active = TRUE
      LEFT JOIN properties p ON p.owner_id = u.id AND p.status = 'active'
      WHERE 1=1
    `;

    const params = [];
    let paramCount = 0;

    if (q) {
      paramCount++;
      query += ` AND (u.name ILIKE $${paramCount} OR u.email ILIKE $${paramCount})`;
      params.push(`%${q}%`);
    }

    if (role) {
      paramCount++;
      query += ` AND u.role = $${paramCount}`;
      params.push(role);
    }

    if (suspended !== undefined) {
      paramCount++;
      query += ` AND u.is_suspended = $${paramCount}`;
      params.push(suspended === 'true');
    }

    query += ` GROUP BY u.id, s.plan, s.expires_at
               ORDER BY u.created_at DESC
               LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;

    params.push(limit, offset);

    const result = await db.query(query, params);

    res.json({
      users: result.rows,
      page: parseInt(page),
      limit: parseInt(limit)
    });
  } catch (error) {
    next(error);
  }
});

// PATCH /api/admin/users/:id/suspend - Suspend user
router.patch('/users/:id/suspend', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    if (!reason) {
      return res.status(400).json({ error: 'Suspension reason required' });
    }

    // Suspend user and pause all their listings
    await db.transaction(async (client) => {
      await client.query(
        `UPDATE users 
         SET is_suspended = TRUE, suspension_reason = $2
         WHERE id = $1`,
        [id, reason]
      );

      await client.query(
        `UPDATE properties 
         SET status = 'paused'
         WHERE owner_id = $1 AND status = 'active'`,
        [id]
      );
    });

    // TODO: Send suspension notification email
    // await sendSuspensionEmail(id, reason);

    res.json({ message: 'User suspended' });
  } catch (error) {
    next(error);
  }
});

// PATCH /api/admin/users/:id/unsuspend - Unsuspend user
router.patch('/users/:id/unsuspend', async (req, res, next) => {
  try {
    const { id } = req.params;

    await db.query(
      `UPDATE users 
       SET is_suspended = FALSE, suspension_reason = NULL
       WHERE id = $1`,
      [id]
    );

    res.json({ message: 'User unsuspended' });
  } catch (error) {
    next(error);
  }
});

// GET /api/admin/reports - Fraud/abuse reports
router.get('/reports', async (req, res, next) => {
  try {
    const { status = 'open' } = req.query;

    const result = await db.query(
      `SELECT 
        r.id, r.reason, r.description, r.created_at, r.status,
        p.id as property_id, p.title as property_title,
        u_reporter.name as reporter_name,
        u_owner.name as owner_name,
        COUNT(*) OVER (PARTITION BY r.property_id) as report_count
       FROM reports r
       JOIN properties p ON p.id = r.property_id
       LEFT JOIN users u_reporter ON u_reporter.id = r.reporter_id
       JOIN users u_owner ON u_owner.id = p.owner_id
       WHERE r.status = $1
       ORDER BY report_count DESC, r.created_at DESC
       LIMIT 50`,
      [status]
    );

    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

// PATCH /api/admin/reports/:id/resolve - Resolve report
router.patch('/reports/:id/resolve', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { action, notes } = req.body; // action: 'remove_listing' | 'warn_owner' | 'dismiss'

    await db.query(
      `UPDATE reports 
       SET status = 'resolved', resolved_by = $2, resolved_at = NOW(), resolution_notes = $3
       WHERE id = $1`,
      [id, req.user.id, notes]
    );

    // TODO: Take action based on type
    if (action === 'remove_listing') {
      // Pause the reported listing
    } else if (action === 'warn_owner') {
      // Send warning email
    }

    res.json({ message: 'Report resolved' });
  } catch (error) {
    next(error);
  }
});

// GET /api/admin/stats - Platform-wide analytics
router.get('/stats', async (req, res, next) => {
  try {
    const { period = 30 } = req.query;

    const result = await db.query(
      'SELECT * FROM get_platform_stats($1)',
      [parseInt(period)]
    );

    res.json(result.rows[0]);
  } catch (error) {
    next(error);
  }
});

module.exports = router;
