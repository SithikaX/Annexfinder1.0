// Payment routes - PayHere integration for subscriptions and boosts
const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const db = require('../config/database');
const { requireAuth, requireRole } = require('../middleware/auth');

const PAYHERE_MERCHANT_ID = process.env.PAYHERE_MERCHANT_ID;
const PAYHERE_MERCHANT_SECRET = process.env.PAYHERE_MERCHANT_SECRET;

// Verify PayHere webhook signature
function verifyPayHereSignature(payload) {
  const {
    merchant_id,
    order_id,
    payhere_amount,
    payhere_currency,
    status_code,
    md5sig
  } = payload;

  // Step 1: MD5 hash of merchant secret (uppercase)
  const secretHash = crypto
    .createHash('md5')
    .update(PAYHERE_MERCHANT_SECRET)
    .digest('hex')
    .toUpperCase();

  // Step 2: Concatenate fields + hashed secret
  const raw = merchant_id + order_id + payhere_amount + payhere_currency + status_code + secretHash;

  // Step 3: MD5 of concatenation (uppercase)
  const expected = crypto
    .createHash('md5')
    .update(raw)
    .digest('hex')
    .toUpperCase();

  return expected === md5sig;
}

// POST /api/payments/subscription/checkout - Create subscription checkout
router.post('/subscription/checkout', requireAuth, requireRole('owner'), async (req, res, next) => {
  try {
    const { plan } = req.body; // 'standard' or 'premium'

    if (!['standard', 'premium'].includes(plan)) {
      return res.status(400).json({ error: 'Invalid plan' });
    }

    const amount = plan === 'standard' ? 2500 : 6000;
    const orderId = `SUB-${req.user.id}-${Date.now()}`;

    // Create pending payment record
    const paymentResult = await db.query(
      `INSERT INTO payments (user_id, amount_lkr, currency, gateway_order_id, payment_type, metadata, status)
       VALUES ($1, $2, 'LKR', $3, 'subscription', $4, 'pending')
       RETURNING id`,
      [req.user.id, amount, orderId, JSON.stringify({ plan })]
    );

    const paymentId = paymentResult.rows[0].id;

    // In production, redirect to PayHere
    const checkoutUrl = `https://sandbox.payhere.lk/pay/checkout?merchant_id=${PAYHERE_MERCHANT_ID}&order_id=${orderId}&amount=${amount}&currency=LKR`;

    res.json({
      payment_id: paymentId,
      checkout_url: checkoutUrl,
      order_id: orderId,
      amount,
      plan
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/payments/boost/checkout - Create listing boost checkout
router.post('/boost/checkout', requireAuth, requireRole('owner'), async (req, res, next) => {
  try {
    const { listing_id, duration_days } = req.body;

    if (![7, 14].includes(duration_days)) {
      return res.status(400).json({ error: 'Duration must be 7 or 14 days' });
    }

    // Verify listing ownership
    const listingResult = await db.query(
      'SELECT id, status FROM properties WHERE id = $1 AND owner_id = $2',
      [listing_id, req.user.id]
    );

    if (listingResult.rows.length === 0) {
      return res.status(404).json({ error: 'Listing not found' });
    }

    if (listingResult.rows[0].status !== 'active') {
      return res.status(400).json({ error: 'Listing must be active to boost' });
    }

    const amount = duration_days === 7 ? 500 : 900;
    const orderId = `BOOST-${listing_id}-${Date.now()}`;

    // Create pending payment
    const paymentResult = await db.query(
      `INSERT INTO payments (user_id, amount_lkr, currency, gateway_order_id, payment_type, metadata, status)
       VALUES ($1, $2, 'LKR', $3, 'boost', $4, 'pending')
       RETURNING id`,
      [req.user.id, amount, orderId, JSON.stringify({ listing_id, duration_days })]
    );

    const paymentId = paymentResult.rows[0].id;

    const checkoutUrl = `https://sandbox.payhere.lk/pay/checkout?merchant_id=${PAYHERE_MERCHANT_ID}&order_id=${orderId}&amount=${amount}&currency=LKR`;

    res.json({
      payment_id: paymentId,
      checkout_url: checkoutUrl,
      order_id: orderId,
      amount,
      duration_days
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/payments/webhook - PayHere server-to-server webhook
router.post('/webhook', async (req, res, next) => {
  try {
    const payload = req.body;

    // CRITICAL: Verify signature before processing
    if (!verifyPayHereSignature(payload)) {
      console.error('PayHere webhook signature verification failed');
      return res.status(400).send('Invalid signature');
    }

    const {
      order_id,
      payhere_amount,
      payhere_currency,
      status_code,
      payment_id: gateway_transaction_id
    } = payload;

    // Only process successful payments (status_code = 2)
    if (status_code !== '2') {
      console.log(`Payment ${order_id} not successful. Status: ${status_code}`);
      return res.status(200).send('OK');
    }

    // Get payment record
    const paymentResult = await db.query(
      'SELECT * FROM payments WHERE gateway_order_id = $1',
      [order_id]
    );

    if (paymentResult.rows.length === 0) {
      console.error(`Payment not found: ${order_id}`);
      return res.status(404).send('Payment not found');
    }

    const payment = paymentResult.rows[0];

    if (payment.status === 'completed') {
      console.log(`Payment ${order_id} already processed`);
      return res.status(200).send('Already processed');
    }

    // Process based on payment type
    await db.transaction(async (client) => {
      if (payment.payment_type === 'subscription') {
        const { plan } = payment.metadata;
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 30); // 30-day subscription

        // Create subscription
        const subResult = await client.query(
          `INSERT INTO subscriptions (user_id, plan, starts_at, expires_at, is_active)
           VALUES ($1, $2, NOW(), $3, TRUE)
           RETURNING id`,
          [payment.user_id, plan, expiresAt]
        );

        // Link payment to subscription
        await client.query(
          'UPDATE payments SET subscription_id = $1 WHERE id = $2',
          [subResult.rows[0].id, payment.id]
        );

        // Activate any paused listings
        await client.query(
          `UPDATE properties 
           SET status = 'active' 
           WHERE owner_id = $1 AND status = 'paused'`,
          [payment.user_id]
        );

        console.log(`Subscription activated for user ${payment.user_id}: ${plan}`);

      } else if (payment.payment_type === 'boost') {
        const { listing_id, duration_days } = payment.metadata;
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + duration_days);

        // Create boost
        await client.query(
          `INSERT INTO boosts (property_id, payment_id, duration_days, expires_at)
           VALUES ($1, $2, $3, $4)`,
          [listing_id, payment.id, duration_days, expiresAt]
        );

        console.log(`Boost activated for listing ${listing_id}: ${duration_days} days`);
      }

      // Mark payment as completed
      await client.query(
        `UPDATE payments 
         SET status = 'completed', gateway_transaction_id = $2, completed_at = NOW()
         WHERE id = $1`,
        [payment.id, gateway_transaction_id]
      );
    });

    // TODO: Send confirmation email
    // await sendPaymentConfirmationEmail(payment.user_id, payment);

    res.status(200).send('OK');
  } catch (error) {
    console.error('Webhook processing error:', error);
    next(error);
  }
});

// GET /api/payments/history - Get user's payment history
router.get('/history', requireAuth, requireRole('owner'), async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT 
        p.id, p.amount_lkr, p.payment_type, p.status, p.created_at, p.completed_at,
        p.metadata,
        s.plan, s.expires_at
       FROM payments p
       LEFT JOIN subscriptions s ON s.id = p.subscription_id
       WHERE p.user_id = $1
       ORDER BY p.created_at DESC
       LIMIT 50`,
      [req.user.id]
    );

    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

module.exports = router;
