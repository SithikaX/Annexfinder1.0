// Enquiry routes - Tenant-Owner messaging system
const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const db = require('../config/database');
const { requireAuth } = require('../middleware/auth');

// POST /api/enquiries - Send first enquiry (Tenant only)
router.post('/', requireAuth, async (req, res, next) => {
  try {
    const errors = validationResult(
      req.body,
      body('property_id').isUUID(),
      body('message').isLength({ min: 20, max: 1000 })
    );

    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
    }

    const { property_id, message } = req.body;

    // Check if property exists and is active
    const propertyResult = await db.query(
      'SELECT id, owner_id, title, status FROM properties WHERE id = $1',
      [property_id]
    );

    if (propertyResult.rows.length === 0) {
      return res.status(404).json({ error: 'Property not found' });
    }

    const property = propertyResult.rows[0];

    if (property.status !== 'active') {
      return res.status(400).json({ error: 'Property is not available' });
    }

    // Don't allow owner to enquire on own property
    if (property.owner_id === req.user.id) {
      return res.status(400).json({ error: 'Cannot enquire on your own listing' });
    }

    // Check if enquiry already exists
    const existingResult = await db.query(
      'SELECT id FROM enquiries WHERE tenant_id = $1 AND property_id = $2',
      [req.user.id, property_id]
    );

    if (existingResult.rows.length > 0) {
      return res.status(409).json({ 
        error: 'You have already enquired about this property',
        enquiry_id: existingResult.rows[0].id
      });
    }

    // Create enquiry and first message in transaction
    await db.transaction(async (client) => {
      // Insert enquiry
      const enquiryResult = await client.query(
        `INSERT INTO enquiries (tenant_id, property_id, last_message_at)
         VALUES ($1, $2, NOW())
         RETURNING id`,
        [req.user.id, property_id]
      );

      const enquiry_id = enquiryResult.rows[0].id;

      // Insert first message
      await client.query(
        `INSERT INTO messages (enquiry_id, sender_id, content)
         VALUES ($1, $2, $3)`,
        [enquiry_id, req.user.id, message]
      );

      // Increment enquiry count on property
      await client.query(
        'UPDATE properties SET enquiry_count = enquiry_count + 1 WHERE id = $1',
        [property_id]
      );
    });

    // TODO: Send email to property owner
    // await sendEnquiryNotification(property.owner_id, property.title, req.user.name, message);

    res.status(201).json({
      message: 'Enquiry sent successfully',
      note: 'The property owner will be notified and can reply soon'
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/enquiries - List all enquiries for current user
router.get('/', requireAuth, async (req, res, next) => {
  try {
    const { status, property_id } = req.query;
    const userId = req.user.id;
    const userRole = req.user.role;

    let query = `
      SELECT 
        e.id,
        e.status,
        e.contact_revealed,
        e.last_message_at,
        e.created_at,
        p.id as property_id,
        p.title as property_title,
        p.rent_lkr,
        (SELECT url FROM property_photos WHERE property_id = p.id AND is_primary = TRUE LIMIT 1) as property_photo,
        u_other.name as other_party_name,
        u_other.email as other_party_email,
        u_other.phone as other_party_phone,
        CASE 
          WHEN $1 = e.tenant_id THEN e.tenant_unread_count
          ELSE e.owner_unread_count
        END as unread_count,
        (
          SELECT content 
          FROM messages 
          WHERE enquiry_id = e.id 
          ORDER BY created_at DESC 
          LIMIT 1
        ) as last_message
      FROM enquiries e
      JOIN properties p ON p.id = e.property_id
      LEFT JOIN users u_other ON 
        CASE 
          WHEN $1 = e.tenant_id THEN u_other.id = p.owner_id
          ELSE u_other.id = e.tenant_id
        END
      WHERE 
    `;

    const params = [userId];
    let paramCount = 1;

    // Filter by role
    if (userRole === 'tenant') {
      query += ` e.tenant_id = $1`;
    } else {
      query += ` p.owner_id = $1`;
    }

    // Filter by status
    if (status) {
      paramCount++;
      query += ` AND e.status = $${paramCount}`;
      params.push(status);
    }

    // Filter by property
    if (property_id) {
      paramCount++;
      query += ` AND e.property_id = $${paramCount}`;
      params.push(property_id);
    }

    query += ` ORDER BY e.last_message_at DESC`;

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

// GET /api/enquiries/:id/messages - Get all messages in thread
router.get('/:id/messages', requireAuth, async (req, res, next) => {
  try {
    const { id } = req.params;

    // Verify user is part of this enquiry
    const enquiryResult = await db.query(
      `SELECT 
        e.id, e.tenant_id, e.contact_revealed,
        p.owner_id,
        u_tenant.name as tenant_name, u_tenant.email as tenant_email, u_tenant.phone as tenant_phone,
        u_owner.name as owner_name, u_owner.email as owner_email, u_owner.phone as owner_phone
       FROM enquiries e
       JOIN properties p ON p.id = e.property_id
       JOIN users u_tenant ON u_tenant.id = e.tenant_id
       JOIN users u_owner ON u_owner.id = p.owner_id
       WHERE e.id = $1`,
      [id]
    );

    if (enquiryResult.rows.length === 0) {
      return res.status(404).json({ error: 'Enquiry not found' });
    }

    const enquiry = enquiryResult.rows[0];

    // Check if user is participant
    const isParticipant = 
      enquiry.tenant_id === req.user.id || 
      enquiry.owner_id === req.user.id;

    if (!isParticipant) {
      return res.status(403).json({ error: 'Not authorized to view this enquiry' });
    }

    // Get all messages
    const messagesResult = await db.query(
      `SELECT 
        m.id, m.content, m.is_read, m.created_at,
        u.name as sender_name,
        m.sender_id = $1 as is_own_message
       FROM messages m
       JOIN users u ON u.id = m.sender_id
       WHERE m.enquiry_id = $2
       ORDER BY m.created_at ASC`,
      [req.user.id, id]
    );

    // Mark as read
    const unreadField = req.user.id === enquiry.tenant_id ? 'tenant_unread_count' : 'owner_unread_count';
    await db.query(
      `UPDATE enquiries SET ${unreadField} = 0 WHERE id = $1`,
      [id]
    );

    // Reveal contact info if owner has replied
    let contact_info = null;
    if (enquiry.contact_revealed) {
      if (req.user.id === enquiry.tenant_id) {
        contact_info = {
          name: enquiry.owner_name,
          email: enquiry.owner_email,
          phone: enquiry.owner_phone
        };
      } else {
        contact_info = {
          name: enquiry.tenant_name,
          email: enquiry.tenant_email,
          phone: enquiry.tenant_phone
        };
      }
    }

    res.json({
      enquiry_id: id,
      messages: messagesResult.rows,
      contact_revealed: enquiry.contact_revealed,
      contact_info
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/enquiries/:id/messages - Reply to enquiry
router.post('/:id/messages', requireAuth, async (req, res, next) => {
  try {
    const errors = validationResult(
      req.body,
      body('content').isLength({ min: 2, max: 1000 })
    );

    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { content } = req.body;

    // Verify participant
    const enquiryResult = await db.query(
      `SELECT e.id, e.tenant_id, e.contact_revealed, p.owner_id
       FROM enquiries e
       JOIN properties p ON p.id = e.property_id
       WHERE e.id = $1`,
      [id]
    );

    if (enquiryResult.rows.length === 0) {
      return res.status(404).json({ error: 'Enquiry not found' });
    }

    const enquiry = enquiryResult.rows[0];

    const isParticipant = 
      enquiry.tenant_id === req.user.id || 
      enquiry.owner_id === req.user.id;

    if (!isParticipant) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    // Insert message
    const messageResult = await db.query(
      `INSERT INTO messages (enquiry_id, sender_id, content)
       VALUES ($1, $2, $3)
       RETURNING id, created_at`,
      [id, req.user.id, content]
    );

    // Update enquiry
    const unreadField = req.user.id === enquiry.tenant_id ? 'owner_unread_count' : 'tenant_unread_count';
    const shouldReveal = !enquiry.contact_revealed && req.user.id === enquiry.owner_id;

    await db.query(
      `UPDATE enquiries 
       SET 
         last_message_at = NOW(),
         ${unreadField} = ${unreadField} + 1,
         status = 'replied',
         contact_revealed = CASE WHEN $2 THEN TRUE ELSE contact_revealed END
       WHERE id = $1`,
      [id, shouldReveal]
    );

    // TODO: Send email notification to other party
    // await sendReplyNotification(...)

    res.status(201).json({
      message: 'Reply sent successfully',
      message_id: messageResult.rows[0].id
    });
  } catch (error) {
    next(error);
  }
});

// PATCH /api/enquiries/:id/status - Update enquiry status
router.patch('/:id/status', requireAuth, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['pending', 'replied', 'closed'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    // Verify participant
    const result = await db.query(
      `UPDATE enquiries e
       SET status = $1, updated_at = NOW()
       FROM properties p
       WHERE e.id = $2 
       AND (e.tenant_id = $3 OR p.owner_id = $3)
       RETURNING e.id`,
      [status, id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Enquiry not found' });
    }

    res.json({ message: 'Status updated' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
