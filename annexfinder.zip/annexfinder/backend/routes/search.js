// Search routes - Core geo-search functionality
const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { optionalAuth } = require('../middleware/auth');

// GET /api/search - Main property search endpoint
router.get('/', optionalAuth, async (req, res, next) => {
  try {
    const {
      uni,          // University name
      lat,          // Workplace latitude
      lng,          // Workplace longitude
      radius = 3000,
      min_rent,
      max_rent,
      type,         // property_type
      furnished,
      bedrooms,
      sort = 'distance',
      page = 1,
      limit = 50
    } = req.query;

    // Validate required params
    if (!uni && (!lat || !lng)) {
      return res.status(400).json({
        error: 'Either university name (uni) or coordinates (lat, lng) required'
      });
    }

    let result;

    // University search
    if (uni) {
      result = await db.query(
        `SELECT * FROM search_by_university(
          $1::text,
          $2::integer,
          $3::integer,
          $4::integer,
          $5::property_type,
          $6::furnished_status,
          $7::smallint,
          $8::integer
        )`,
        [
          uni,
          parseInt(radius),
          min_rent ? parseInt(min_rent) : null,
          max_rent ? parseInt(max_rent) : null,
          type || null,
          furnished || null,
          bedrooms ? parseInt(bedrooms) : null,
          parseInt(limit)
        ]
      );
    } else {
      // Workplace coordinate search
      result = await db.query(
        `SELECT * FROM search_by_workplace(
          $1::double precision,
          $2::double precision,
          $3::integer,
          $4::integer,
          $5::integer,
          $6::property_type,
          $7::furnished_status,
          $8::smallint,
          $9::integer
        )`,
        [
          parseFloat(lat),
          parseFloat(lng),
          parseInt(radius),
          min_rent ? parseInt(min_rent) : null,
          max_rent ? parseInt(max_rent) : null,
          type || null,
          furnished || null,
          bedrooms ? parseInt(bedrooms) : null,
          parseInt(limit)
        ]
      );
    }

    // Apply additional sorting if requested
    let results = result.rows;

    if (sort === 'rent_asc') {
      results.sort((a, b) => a.rent_lkr - b.rent_lkr);
    } else if (sort === 'rent_desc') {
      results.sort((a, b) => b.rent_lkr - a.rent_lkr);
    } else if (sort === 'newest') {
      results.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    }

    // Add saved status for authenticated users
    if (req.user) {
      const propertyIds = results.map(r => r.id);
      if (propertyIds.length > 0) {
        const savedResult = await db.query(
          `SELECT property_id FROM saved_listings 
           WHERE user_id = $1 AND property_id = ANY($2)`,
          [req.user.id, propertyIds]
        );
        const savedIds = new Set(savedResult.rows.map(r => r.property_id));
        results = results.map(r => ({
          ...r,
          is_saved: savedIds.has(r.id)
        }));
      }
    }

    res.json({
      results,
      count: results.length,
      filters: {
        uni,
        lat,
        lng,
        radius,
        min_rent,
        max_rent,
        type,
        furnished,
        bedrooms,
        sort
      }
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/search/universities - Get all universities for autocomplete
router.get('/universities', async (req, res, next) => {
  try {
    const { q } = req.query;

    let query = 'SELECT id, name, short_name, city FROM universities';
    let params = [];

    if (q) {
      query += ' WHERE name ILIKE $1 OR short_name ILIKE $1';
      params = [`%${q}%`];
    }

    query += ' ORDER BY name LIMIT 20';

    const result = await db.query(query, params);

    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

// GET /api/search/cities - Get all cities for filters
router.get('/cities', async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT DISTINCT city, COUNT(*) as count
       FROM properties
       WHERE status = 'active' AND city IS NOT NULL
       GROUP BY city
       ORDER BY count DESC, city ASC
       LIMIT 20`
    );

    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

// GET /api/search/featured - Get featured/boosted listings for homepage
router.get('/featured', async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT 
        p.id, p.title, p.rent_lkr, p.property_type, p.city,
        p.bedrooms, p.is_verified,
        TRUE as is_boosted,
        (SELECT url FROM property_photos WHERE property_id = p.id AND is_primary = TRUE LIMIT 1) as photo_url
       FROM properties p
       INNER JOIN boosts b ON b.property_id = p.id AND b.expires_at > NOW()
       WHERE p.status = 'active'
       ORDER BY b.created_at DESC
       LIMIT 8`
    );

    // If not enough boosted, fill with verified listings
    if (result.rows.length < 6) {
      const fillResult = await db.query(
        `SELECT 
          p.id, p.title, p.rent_lkr, p.property_type, p.city,
          p.bedrooms, p.is_verified,
          FALSE as is_boosted,
          (SELECT url FROM property_photos WHERE property_id = p.id AND is_primary = TRUE LIMIT 1) as photo_url
         FROM properties p
         WHERE p.status = 'active' AND p.is_verified = TRUE
         AND p.id NOT IN (${result.rows.map(r => `'${r.id}'`).join(',') || "''"})
         ORDER BY p.created_at DESC
         LIMIT ${6 - result.rows.length}`
      );

      result.rows.push(...fillResult.rows);
    }

    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

module.exports = router;
