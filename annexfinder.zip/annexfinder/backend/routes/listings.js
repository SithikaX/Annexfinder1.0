// Listings routes - Property CRUD operations
const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const db = require('../config/database');
const { requireAuth, requireRole, optionalAuth } = require('../middleware/auth');

// Validation for new listing
const validateListing = [
  body('title').trim().isLength({ min: 10, max: 160 }),
  body('description').trim().isLength({ min: 80 }),
  body('address').trim().isLength({ min: 10, max: 300 }),
  body('lat').isFloat({ min: 5, max: 10 }),
  body('lng').isFloat({ min: 75, max: 85 }),
  body('rent_lkr').isInt({ min: 1, max: 10000000 }),
  body('property_type').isIn(['annex', 'room', 'apartment', 'house', 'boarding']),
  body('furnished').isIn(['furnished', 'semi', 'unfurnished']),
  body('bedrooms').isInt({ min: 0, max: 20 }),
  body('bathrooms').isInt({ min: 0, max: 10 }),
  body('available_from').isISO8601(),
  body('amenities').optional().isArray(),
  body('target_audience').optional().isIn(['students', 'professionals', 'both'])
];

// GET /api/listings/:id - Get property detail
router.get('/:id', optionalAuth, async (req, res, next) => {
  try {
    const { id } = req.params;

    // Get property with photos
    const result = await db.query(
      `SELECT 
        p.*,
        u.name as owner_name,
        u.phone as owner_phone,
        u.email as owner_email,
        CASE WHEN b.id IS NOT NULL THEN TRUE ELSE FALSE END as is_boosted,
        COALESCE(json_agg(
          json_build_object(
            'id', ph.id,
            'url', ph.url,
            'is_primary', ph.is_primary,
            'display_order', ph.display_order
          ) ORDER BY ph.display_order
        ) FILTER (WHERE ph.id IS NOT NULL), '[]') as photos,
        (SELECT name FROM universities WHERE id = p.nearest_university_id) as nearest_university_name
       FROM properties p
       LEFT JOIN users u ON u.id = p.owner_id
       LEFT JOIN property_photos ph ON ph.property_id = p.id
       LEFT JOIN boosts b ON b.property_id = p.id AND b.expires_at > NOW()
       WHERE p.id = $1
       GROUP BY p.id, u.name, u.phone, u.email, b.id`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Property not found' });
    }

    const property = result.rows[0];

    // Only show active listings to non-owners
    if (property.status !== 'active' && (!req.user || req.user.id !== property.owner_id)) {
      return res.status(404).json({ error: 'Property not found' });
    }

    // Track view (deduped by IP + date)
    if (req.ip) {
      await db.query(
        `INSERT INTO property_views (property_id, user_id, ip_address, user_agent)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT DO NOTHING`,
        [id, req.user?.id || null, req.ip, req.headers['user-agent']]
      );
    }

    // Increment view counter
    await db.query(
      'UPDATE properties SET view_count = view_count + 1 WHERE id = $1',
      [id]
    );

    // Check if saved (for authenticated users)
    if (req.user) {
      const savedResult = await db.query(
        'SELECT id FROM saved_listings WHERE user_id = $1 AND property_id = $2',
        [req.user.id, id]
      );
      property.is_saved = savedResult.rows.length > 0;
    }

    // Get similar properties
    const similarResult = await db.query(
      'SELECT * FROM get_similar_properties($1, 4)',
      [id]
    );
    property.similar_properties = similarResult.rows;

    res.json(property);
  } catch (error) {
    next(error);
  }
});

// POST /api/listings - Create new listing (Owner only)
router.post('/', requireAuth, requireRole('owner'), validateListing, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
    }

    // Check if owner can add more listings
    const canAdd = await db.query(
      'SELECT can_add_listing($1) as can_add',
      [req.user.id]
    );

    if (!canAdd.rows[0].can_add) {
      return res.status(402).json({
        error: 'Listing limit reached',
        message: 'Upgrade your plan to add more listings'
      });
    }

    const {
      title, description, address, city, district,
      lat, lng, rent_lkr, property_type, furnished,
      bedrooms, bathrooms, amenities, available_from,
      target_audience, nearest_university_id
    } = req.body;

    // Insert property
    const result = await db.query(
      `INSERT INTO properties (
        owner_id, title, description, address, city, district,
        lat, lng, rent_lkr, property_type, furnished,
        bedrooms, bathrooms, amenities, available_from,
        target_audience, nearest_university_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
      RETURNING id, status, created_at`,
      [
        req.user.id, title, description, address, city, district,
        lat, lng, rent_lkr, property_type, furnished,
        bedrooms, bathrooms, amenities, available_from,
        target_audience || 'both', nearest_university_id
      ]
    );

    const property = result.rows[0];

    res.status(201).json({
      message: 'Listing created successfully',
      property,
      note: 'Listing is pending approval and will be reviewed shortly'
    });
  } catch (error) {
    next(error);
  }
});

// PATCH /api/listings/:id - Update listing (Owner only)
router.patch('/:id', requireAuth, requireRole('owner'), async (req, res, next) => {
  try {
    const { id } = req.params;

    // Check ownership
    const ownerCheck = await db.query(
      'SELECT id, status FROM properties WHERE id = $1 AND owner_id = $2',
      [id, req.user.id]
    );

    if (ownerCheck.rows.length === 0) {
      return res.status(403).json({ error: 'Not your listing' });
    }

    const allowedFields = [
      'title', 'description', 'rent_lkr', 'furnished',
      'amenities', 'available_from'
    ];

    const updates = {};
    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field];
      }
    }

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    // Build dynamic UPDATE query
    const setClause = Object.keys(updates)
      .map((key, idx) => `${key} = $${idx + 2}`)
      .join(', ');

    const values = [id, ...Object.values(updates)];

    const result = await db.query(
      `UPDATE properties 
       SET ${setClause}, updated_at = NOW()
       WHERE id = $1
       RETURNING *`,
      values
    );

    res.json({
      message: 'Listing updated successfully',
      property: result.rows[0]
    });
  } catch (error) {
    next(error);
  }
});

// PATCH /api/listings/:id/status - Change listing status (Owner only)
router.patch('/:id/status', requireAuth, requireRole('owner'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['active', 'paused', 'rented'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    const result = await db.query(
      `UPDATE properties 
       SET status = $1, updated_at = NOW()
       WHERE id = $2 AND owner_id = $3
       RETURNING id, status`,
      [status, id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Listing not found' });
    }

    res.json({
      message: 'Status updated',
      property: result.rows[0]
    });
  } catch (error) {
    next(error);
  }
});

// DELETE /api/listings/:id - Soft delete listing (Owner only)
router.delete('/:id', requireAuth, requireRole('owner'), async (req, res, next) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `UPDATE properties 
       SET status = 'rented', updated_at = NOW()
       WHERE id = $1 AND owner_id = $2
       RETURNING id`,
      [id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Listing not found' });
    }

    res.json({ message: 'Listing deleted successfully' });
  } catch (error) {
    next(error);
  }
});

// GET /api/listings/:id/similar - Get similar properties
router.get('/:id/similar', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { limit = 4 } = req.query;

    const result = await db.query(
      'SELECT * FROM get_similar_properties($1, $2)',
      [id, parseInt(limit)]
    );

    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

module.exports = router;
