// AnnexFinder Backend Server
// Node.js + Express + PostgreSQL + PostGIS

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const cron = require('node-cron');

// Database
const db = require('./config/database');

// Routes
const authRoutes = require('./routes/auth');
const searchRoutes = require('./routes/search');
const listingRoutes = require('./routes/listings');
const enquiryRoutes = require('./routes/enquiries');
const ownerRoutes = require('./routes/owner');
const adminRoutes = require('./routes/admin');
const paymentRoutes = require('./routes/payments');

// Middleware
const errorHandler = require('./middleware/errorHandler');
const { runCronJobs } = require('./utils/cronJobs');

const app = express();
const PORT = process.env.PORT || 5000;

// ============================================
// MIDDLEWARE
// ============================================

app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// ============================================
// ROUTES
// ============================================

app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    service: 'AnnexFinder API'
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/listings', listingRoutes);
app.use('/api/enquiries', enquiryRoutes);
app.use('/api/owner', ownerRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/payments', paymentRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Error handler (must be last)
app.use(errorHandler);

// ============================================
// CRON JOBS
// ============================================

// Run every day at 1 AM - expire subscriptions
cron.schedule('0 1 * * *', async () => {
  console.log('Running subscription expiry check...');
  try {
    const result = await db.query('SELECT expire_subscriptions()');
    console.log(`Expired ${result.rows[0].expire_subscriptions} subscriptions`);
  } catch (error) {
    console.error('Subscription expiry error:', error);
  }
});

// Run every hour - remove expired boosts
cron.schedule('0 * * * *', async () => {
  console.log('Removing expired boosts...');
  try {
    const result = await db.query('SELECT remove_expired_boosts()');
    console.log(`Removed ${result.rows[0].remove_expired_boosts} expired boosts`);
  } catch (error) {
    console.error('Boost removal error:', error);
  }
});

// Run every day at 2 AM - deduplicate views
cron.schedule('0 2 * * *', async () => {
  console.log('Deduplicating property views...');
  try {
    const result = await db.query('SELECT deduplicate_property_views()');
    console.log(`Deduplicated ${result.rows[0].deduplicate_property_views} views`);
  } catch (error) {
    console.error('View deduplication error:', error);
  }
});

// ============================================
// START SERVER
// ============================================

app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════╗
║                                               ║
║         AnnexFinder API Server                ║
║         Running on port ${PORT}                 ║
║                                               ║
║  Database: ${process.env.DB_NAME || 'annexfinder'}              ║
║  Environment: ${process.env.NODE_ENV || 'development'}         ║
║                                               ║
╚═══════════════════════════════════════════════╝
  `);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await db.pool.end();
  process.exit(0);
});

module.exports = app;
