#!/bin/bash

# AnnexFinder Quick Setup Script
# Run this script to set up the entire platform

set -e

echo "╔══════════════════════════════════════════════════╗"
echo "║                                                  ║"
echo "║         AnnexFinder Platform Setup              ║"
echo "║         Student & Professional Housing          ║"
echo "║                                                  ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# Check prerequisites
command -v node >/dev/null 2>&1 || { echo "❌ Node.js is required but not installed. Install from nodejs.org"; exit 1; }
command -v psql >/dev/null 2>&1 || { echo "❌ PostgreSQL is required but not installed."; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "❌ npm is required but not installed."; exit 1; }

echo "✅ Prerequisites check passed"
echo ""

# Database setup
echo "📊 Setting up database..."
echo "Enter your PostgreSQL password when prompted:"

createdb annexfinder 2>/dev/null || echo "Database 'annexfinder' already exists"

echo "Running schema..."
psql annexfinder < database/schema.sql

echo "Running spatial queries..."
psql annexfinder < database/queries.sql

echo "✅ Database setup complete"
echo ""

# Backend setup
echo "🚀 Setting up backend..."
cd backend

if [ ! -f .env ]; then
  cp ../.env.example .env
  echo "⚠️  Created .env file - please edit it with your credentials"
fi

npm install
echo "✅ Backend dependencies installed"
cd ..
echo ""

# Frontend setup
echo "🎨 Setting up frontend..."
cd frontend

if [ ! -f .env ]; then
  cp ../.env.example .env
  echo "⚠️  Created .env file - please edit it with your credentials"
fi

npm install
echo "✅ Frontend dependencies installed"
cd ..
echo ""

echo "╔══════════════════════════════════════════════════╗"
echo "║                                                  ║"
echo "║         Setup Complete! 🎉                      ║"
echo "║                                                  ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo ""
echo "1. Edit environment files:"
echo "   - backend/.env (database credentials, JWT secret, PayHere keys)"
echo "   - frontend/.env (API URL, Google Maps key)"
echo ""
echo "2. Start the backend:"
echo "   cd backend && npm run dev"
echo ""
echo "3. Start the frontend (in another terminal):"
echo "   cd frontend && npm run dev"
echo ""
echo "4. Open http://localhost:3000 in your browser"
echo ""
echo "📖 Read README.md for detailed documentation"
echo "🐛 Report issues on GitHub"
echo ""
echo "Happy building! 🏠"
