# 🚀 START HERE - Quick Setup Guide

Welcome to AnnexFinder! Follow these steps to get running in **15 minutes**.

---

## ✅ Step 1: Install Prerequisites

### You need these installed first:

1. **Node.js** (version 18 or higher)
   - Download: https://nodejs.org
   - Check: `node --version` (should show v18.x or higher)

2. **PostgreSQL** (version 15 or higher)
   - **Windows**: https://www.postgresql.org/download/windows/
   - **Mac**: `brew install postgresql`
   - **Linux**: `sudo apt install postgresql postgresql-contrib`
   - Check: `psql --version`

3. **PostGIS** (PostgreSQL extension for maps)
   - **Windows**: Included in PostgreSQL installer (check "PostGIS" during install)
   - **Mac**: `brew install postgis`
   - **Linux**: `sudo apt install postgis postgresql-15-postgis-3`

---

## ✅ Step 2: Setup Database

Open terminal/command prompt and run:

```bash
# Create the database
createdb annexfinder

# Load the schema (creates all tables)
psql annexfinder < database/schema.sql

# Load spatial functions
psql annexfinder < database/queries.sql

# Verify it worked (should show 15)
psql annexfinder -c "SELECT COUNT(*) FROM universities;"
```

**If you get password prompts**, enter your PostgreSQL password.

---

## ✅ Step 3: Install Backend Dependencies

```bash
# Go to backend folder
cd backend

# Install packages (takes 1-2 minutes)
npm install

# Create environment file
cp ../.env.example .env
```

**Edit `backend/.env` file** (use any text editor):

```bash
# Required - Your database password
DB_PASSWORD=your_postgres_password_here

# Required - Any long random string
JWT_SECRET=make-this-a-very-long-random-string-at-least-32-characters

# Optional - Add these later for payments
PAYHERE_MERCHANT_ID=
PAYHERE_MERCHANT_SECRET=
```

---

## ✅ Step 4: Install Frontend Dependencies

```bash
# Go to frontend folder
cd ../frontend

# Install packages (takes 1-2 minutes)
npm install

# Create environment file
cp ../.env.example .env
```

**Edit `frontend/.env` file**:

```bash
NEXT_PUBLIC_API_URL=http://localhost:5000
```

That's all you need for now!

---

## ✅ Step 5: Start the Application

### Open TWO terminal windows:

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
```

**Wait for this message:**
```
✓ Database connected successfully
AnnexFinder API Server
Running on port 5000
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```

**Wait for this message:**
```
▲ Next.js 14.0.4
- Local: http://localhost:3000
```

---

## ✅ Step 6: Open Your Browser

Go to: **http://localhost:3000**

You should see the beautiful AnnexFinder home page! 🎉

---

## 🧪 Test It Works

### Test the API:
Open: http://localhost:5000/health

Should show: `{"status":"ok",...}`

### Test the database:
```bash
psql annexfinder -c "SELECT name, city FROM universities LIMIT 5;"
```

Should show 5 universities.

---

## 🎯 What's Next?

1. **Read CHECKLIST.md** - Your step-by-step task list
2. **Create test data** - Add your first property listing
3. **Build pages** - Search results, property detail, login
4. **Deploy** - See DEPLOYMENT.md when ready

---

## 🐛 Troubleshooting

### "createdb: command not found"
PostgreSQL isn't installed or not in PATH.
- **Windows**: Add `C:\Program Files\PostgreSQL\15\bin` to PATH
- **Mac/Linux**: Reinstall PostgreSQL

### "psql: FATAL: database 'annexfinder' does not exist"
The database wasn't created. Run:
```bash
createdb annexfinder
```

### "Port 5000 already in use"
Something is using port 5000. Kill it:
```bash
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Mac/Linux
lsof -ti:5000 | xargs kill -9
```

### "Module not found"
Dependencies aren't installed. Run:
```bash
cd backend
npm install

cd ../frontend
npm install
```

### "Cannot connect to database"
Check PostgreSQL is running:
```bash
# Windows
services.msc (look for postgresql)

# Mac
brew services start postgresql

# Linux
sudo systemctl start postgresql
```

---

## 📚 Documentation

- **START_HERE.md** ← You are here
- **CHECKLIST.md** - Daily task list
- **GETTING_STARTED.md** - Detailed guide
- **README.md** - Complete platform overview
- **DEPLOYMENT.md** - Production deployment

---

## 🆘 Still Stuck?

Check if you have:
- [ ] Node.js 18+ installed (`node --version`)
- [ ] PostgreSQL running (`psql --version`)
- [ ] Database created (`psql annexfinder -c "SELECT 1;"`)
- [ ] Backend .env file with DB_PASSWORD set
- [ ] Frontend .env file with API_URL set
- [ ] Both servers running in separate terminals

---

## ✅ Success!

When you see the home page at http://localhost:3000, you're done with setup!

Next: Open **CHECKLIST.md** and start building! 🚀

---

**Questions?** All files have detailed inline comments. Start reading!
