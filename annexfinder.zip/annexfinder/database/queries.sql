-- AnnexFinder PostGIS Spatial Queries
-- Geography-based distance calculations for Sri Lankan property search

-- ============================================
-- UNIVERSITY PROXIMITY SEARCH
-- ============================================

-- Search properties near a university
-- Parameters: $1 = university_name, $2 = radius_metres, $3 = limit
CREATE OR REPLACE FUNCTION search_by_university(
    p_university_name TEXT,
    p_radius_metres INTEGER DEFAULT 3000,
    p_min_rent INTEGER DEFAULT NULL,
    p_max_rent INTEGER DEFAULT NULL,
    p_property_type property_type DEFAULT NULL,
    p_furnished furnished_status DEFAULT NULL,
    p_bedrooms SMALLINT DEFAULT NULL,
    p_limit INTEGER DEFAULT 50
)
RETURNS TABLE (
    id UUID,
    title VARCHAR(160),
    rent_lkr INTEGER,
    property_type property_type,
    bedrooms SMALLINT,
    bathrooms SMALLINT,
    furnished furnished_status,
    is_verified BOOLEAN,
    is_boosted BOOLEAN,
    distance_metres NUMERIC,
    distance_label TEXT,
    photo_url VARCHAR(500),
    city VARCHAR(100),
    created_at TIMESTAMPTZ
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.id,
        p.title,
        p.rent_lkr,
        p.property_type,
        p.bedrooms,
        p.bathrooms,
        p.furnished,
        p.is_verified,
        CASE WHEN b.id IS NOT NULL THEN TRUE ELSE FALSE END AS is_boosted,
        ROUND(ST_Distance(p.location, u.location)::numeric, 0) AS distance_metres,
        distance_label(ST_Distance(p.location, u.location)) AS distance_label,
        (SELECT url FROM property_photos WHERE property_id = p.id AND is_primary = TRUE LIMIT 1) AS photo_url,
        p.city,
        p.created_at
    FROM properties p
    CROSS JOIN LATERAL (
        SELECT location FROM universities 
        WHERE name ILIKE '%' || p_university_name || '%' 
        LIMIT 1
    ) u
    LEFT JOIN boosts b ON b.property_id = p.id AND b.expires_at > NOW()
    WHERE 
        p.status = 'active'
        AND ST_DWithin(p.location, u.location, p_radius_metres)
        AND (p_min_rent IS NULL OR p.rent_lkr >= p_min_rent)
        AND (p_max_rent IS NULL OR p.rent_lkr <= p_max_rent)
        AND (p_property_type IS NULL OR p.property_type = p_property_type)
        AND (p_furnished IS NULL OR p.furnished = p_furnished)
        AND (p_bedrooms IS NULL OR p.bedrooms >= p_bedrooms)
    ORDER BY 
        is_boosted DESC,
        distance_metres ASC
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- WORKPLACE COORDINATE SEARCH
-- ============================================

-- Search properties near workplace coordinates
CREATE OR REPLACE FUNCTION search_by_workplace(
    p_lat DOUBLE PRECISION,
    p_lng DOUBLE PRECISION,
    p_radius_metres INTEGER DEFAULT 3000,
    p_min_rent INTEGER DEFAULT NULL,
    p_max_rent INTEGER DEFAULT NULL,
    p_property_type property_type DEFAULT NULL,
    p_furnished furnished_status DEFAULT NULL,
    p_bedrooms SMALLINT DEFAULT NULL,
    p_limit INTEGER DEFAULT 50
)
RETURNS TABLE (
    id UUID,
    title VARCHAR(160),
    rent_lkr INTEGER,
    property_type property_type,
    bedrooms SMALLINT,
    bathrooms SMALLINT,
    furnished furnished_status,
    is_verified BOOLEAN,
    is_boosted BOOLEAN,
    distance_metres NUMERIC,
    distance_label TEXT,
    photo_url VARCHAR(500),
    city VARCHAR(100),
    created_at TIMESTAMPTZ
) AS $$
DECLARE
    v_target_location GEOGRAPHY;
BEGIN
    v_target_location := ST_SetSRID(ST_MakePoint(p_lng, p_lat), 4326)::geography;
    
    RETURN QUERY
    SELECT 
        p.id,
        p.title,
        p.rent_lkr,
        p.property_type,
        p.bedrooms,
        p.bathrooms,
        p.furnished,
        p.is_verified,
        CASE WHEN b.id IS NOT NULL THEN TRUE ELSE FALSE END AS is_boosted,
        ROUND(ST_Distance(p.location, v_target_location)::numeric, 0) AS distance_metres,
        distance_label(ST_Distance(p.location, v_target_location)) AS distance_label,
        (SELECT url FROM property_photos WHERE property_id = p.id AND is_primary = TRUE LIMIT 1) AS photo_url,
        p.city,
        p.created_at
    FROM properties p
    LEFT JOIN boosts b ON b.property_id = p.id AND b.expires_at > NOW()
    WHERE 
        p.status = 'active'
        AND ST_DWithin(p.location, v_target_location, p_radius_metres)
        AND (p_min_rent IS NULL OR p.rent_lkr >= p_min_rent)
        AND (p_max_rent IS NULL OR p.rent_lkr <= p_max_rent)
        AND (p_property_type IS NULL OR p.property_type = p_property_type)
        AND (p_furnished IS NULL OR p.furnished = p_furnished)
        AND (p_bedrooms IS NULL OR p.bedrooms >= p_bedrooms)
    ORDER BY 
        is_boosted DESC,
        distance_metres ASC
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- SIMILAR PROPERTIES (For detail page)
-- ============================================

CREATE OR REPLACE FUNCTION get_similar_properties(
    p_property_id UUID,
    p_limit INTEGER DEFAULT 4
)
RETURNS TABLE (
    id UUID,
    title VARCHAR(160),
    rent_lkr INTEGER,
    property_type property_type,
    bedrooms SMALLINT,
    distance_metres NUMERIC,
    photo_url VARCHAR(500)
) AS $$
BEGIN
    RETURN QUERY
    WITH base_property AS (
        SELECT location, rent_lkr, property_type 
        FROM properties 
        WHERE id = p_property_id
    )
    SELECT 
        p.id,
        p.title,
        p.rent_lkr,
        p.property_type,
        p.bedrooms,
        ROUND(ST_Distance(p.location, bp.location)::numeric, 0) AS distance_metres,
        (SELECT url FROM property_photos WHERE property_id = p.id AND is_primary = TRUE LIMIT 1) AS photo_url
    FROM properties p, base_property bp
    WHERE 
        p.id != p_property_id
        AND p.status = 'active'
        AND ST_DWithin(p.location, bp.location, 3000)
        AND p.rent_lkr BETWEEN (bp.rent_lkr * 0.8) AND (bp.rent_lkr * 1.2)
    ORDER BY 
        CASE WHEN p.property_type = bp.property_type THEN 0 ELSE 1 END,
        distance_metres ASC
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- ANALYTICS QUERIES
-- ============================================

-- Owner analytics for a specific period
CREATE OR REPLACE FUNCTION get_owner_analytics(
    p_owner_id UUID,
    p_days INTEGER DEFAULT 30
)
RETURNS TABLE (
    property_id UUID,
    property_title VARCHAR(160),
    views BIGINT,
    enquiries BIGINT,
    saves BIGINT,
    enquiry_rate NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.id,
        p.title,
        COUNT(DISTINCT v.id) AS views,
        COUNT(DISTINCT e.id) AS enquiries,
        COUNT(DISTINCT s.id) AS saves,
        ROUND(
            COUNT(DISTINCT e.id)::numeric / 
            NULLIF(COUNT(DISTINCT v.id), 0) * 100, 
            1
        ) AS enquiry_rate
    FROM properties p
    LEFT JOIN property_views v 
        ON v.property_id = p.id 
        AND v.viewed_at >= NOW() - (p_days || ' days')::INTERVAL
    LEFT JOIN enquiries e 
        ON e.property_id = p.id 
        AND e.created_at >= NOW() - (p_days || ' days')::INTERVAL
    LEFT JOIN saved_listings s 
        ON s.property_id = p.id 
        AND s.saved_at >= NOW() - (p_days || ' days')::INTERVAL
    WHERE p.owner_id = p_owner_id
    GROUP BY p.id, p.title
    ORDER BY views DESC;
END;
$$ LANGUAGE plpgsql;

-- Platform-wide stats for admin
CREATE OR REPLACE FUNCTION get_platform_stats(
    p_days INTEGER DEFAULT 30
)
RETURNS TABLE (
    total_properties BIGINT,
    active_properties BIGINT,
    total_users BIGINT,
    total_owners BIGINT,
    total_enquiries BIGINT,
    total_views BIGINT,
    conversion_rate NUMERIC,
    mrr_lkr BIGINT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        (SELECT COUNT(*) FROM properties) AS total_properties,
        (SELECT COUNT(*) FROM properties WHERE status = 'active') AS active_properties,
        (SELECT COUNT(*) FROM users) AS total_users,
        (SELECT COUNT(*) FROM users WHERE role = 'owner') AS total_owners,
        (SELECT COUNT(*) FROM enquiries WHERE created_at >= NOW() - (p_days || ' days')::INTERVAL) AS total_enquiries,
        (SELECT COUNT(*) FROM property_views WHERE viewed_at >= NOW() - (p_days || ' days')::INTERVAL) AS total_views,
        ROUND(
            (SELECT COUNT(*) FROM enquiries WHERE created_at >= NOW() - (p_days || ' days')::INTERVAL)::numeric /
            NULLIF((SELECT COUNT(*) FROM property_views WHERE viewed_at >= NOW() - (p_days || ' days')::INTERVAL), 0) * 100,
            2
        ) AS conversion_rate,
        (
            SELECT SUM(
                CASE 
                    WHEN plan = 'standard' THEN 2500
                    WHEN plan = 'premium' THEN 6000
                    ELSE 0
                END
            )
            FROM subscriptions
            WHERE is_active = TRUE
        ) AS mrr_lkr;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- CRON JOB QUERIES
-- ============================================

-- Expire subscriptions (run daily)
CREATE OR REPLACE FUNCTION expire_subscriptions()
RETURNS INTEGER AS $$
DECLARE
    v_count INTEGER;
BEGIN
    -- Pause all listings from expired subscriptions
    UPDATE properties
    SET status = 'paused'
    WHERE owner_id IN (
        SELECT user_id 
        FROM subscriptions 
        WHERE is_active = TRUE 
        AND expires_at < NOW()
    )
    AND status = 'active';
    
    -- Mark subscriptions as inactive
    UPDATE subscriptions
    SET is_active = FALSE
    WHERE is_active = TRUE 
    AND expires_at < NOW();
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- Remove expired boosts (run hourly)
CREATE OR REPLACE FUNCTION remove_expired_boosts()
RETURNS INTEGER AS $$
DECLARE
    v_count INTEGER;
BEGIN
    DELETE FROM boosts
    WHERE expires_at < NOW();
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- Deduplicate property views (run daily)
CREATE OR REPLACE FUNCTION deduplicate_property_views()
RETURNS INTEGER AS $$
DECLARE
    v_count INTEGER;
BEGIN
    DELETE FROM property_views a
    WHERE id > (
        SELECT MIN(id)
        FROM property_views b
        WHERE a.property_id = b.property_id
        AND a.ip_address = b.ip_address
        AND DATE(a.viewed_at) = DATE(b.viewed_at)
    );
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;
