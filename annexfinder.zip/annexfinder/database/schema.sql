-- AnnexFinder Database Schema
-- PostgreSQL 15 + PostGIS
-- Full schema for property marketplace platform

-- ============================================
-- EXTENSIONS
-- ============================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;
CREATE EXTENSION IF NOT EXISTS pg_trgm; -- For text search

-- ============================================
-- ENUMS
-- ============================================

CREATE TYPE user_role AS ENUM ('tenant', 'owner', 'admin');
CREATE TYPE property_type AS ENUM ('annex', 'room', 'apartment', 'house', 'boarding');
CREATE TYPE property_status AS ENUM ('pending', 'active', 'paused', 'rented', 'rejected');
CREATE TYPE furnished_status AS ENUM ('furnished', 'semi', 'unfurnished');
CREATE TYPE target_audience AS ENUM ('students', 'professionals', 'both');
CREATE TYPE subscription_plan AS ENUM ('free', 'standard', 'premium');
CREATE TYPE payment_status AS ENUM ('pending', 'completed', 'failed', 'refunded');
CREATE TYPE enquiry_status AS ENUM ('pending', 'replied', 'closed');

-- ============================================
-- USERS TABLE
-- ============================================

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255), -- NULL for OAuth users
    name VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    role user_role NOT NULL DEFAULT 'tenant',
    google_id VARCHAR(100) UNIQUE,
    email_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(100),
    reset_token VARCHAR(100),
    reset_token_expires TIMESTAMPTZ,
    is_suspended BOOLEAN DEFAULT FALSE,
    suspension_reason TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_google_id ON users(google_id) WHERE google_id IS NOT NULL;

-- ============================================
-- UNIVERSITIES TABLE (Pre-seeded)
-- ============================================

CREATE TABLE universities (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    short_name VARCHAR(100),
    city VARCHAR(100) NOT NULL,
    district VARCHAR(100),
    lat DOUBLE PRECISION NOT NULL,
    lng DOUBLE PRECISION NOT NULL,
    location GEOGRAPHY(Point, 4326),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_universities_location ON universities USING GIST(location);
CREATE INDEX idx_universities_name ON universities USING GIN(name gin_trgm_ops);

-- ============================================
-- PROPERTIES TABLE
-- ============================================

CREATE TABLE properties (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(160) NOT NULL,
    description TEXT NOT NULL CHECK (LENGTH(description) >= 80),
    address VARCHAR(300) NOT NULL,
    city VARCHAR(100),
    district VARCHAR(100),
    lat DOUBLE PRECISION NOT NULL,
    lng DOUBLE PRECISION NOT NULL,
    location GEOGRAPHY(Point, 4326),
    rent_lkr INTEGER NOT NULL CHECK (rent_lkr > 0 AND rent_lkr <= 10000000),
    property_type property_type NOT NULL,
    status property_status DEFAULT 'pending',
    furnished furnished_status NOT NULL,
    bedrooms SMALLINT CHECK (bedrooms >= 0),
    bathrooms SMALLINT CHECK (bathrooms >= 0),
    amenities TEXT[],
    available_from DATE NOT NULL,
    is_verified BOOLEAN DEFAULT FALSE,
    target_audience target_audience DEFAULT 'both',
    nearest_university_id INTEGER REFERENCES universities(id),
    rejection_reason TEXT,
    view_count INTEGER DEFAULT 0,
    enquiry_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Critical spatial index
CREATE INDEX idx_properties_location ON properties USING GIST(location);

-- Filter indexes
CREATE INDEX idx_properties_status ON properties(status);
CREATE INDEX idx_properties_owner ON properties(owner_id);
CREATE INDEX idx_properties_rent ON properties(rent_lkr);
CREATE INDEX idx_properties_type ON properties(property_type);
CREATE INDEX idx_properties_city ON properties(city);

-- Partial index for active listings (most common query)
CREATE INDEX idx_properties_active_location 
ON properties(status) INCLUDE(rent_lkr, bedrooms, furnished, property_type)
WHERE status = 'active';

-- Full-text search on title and description
CREATE INDEX idx_properties_search ON properties 
USING GIN(to_tsvector('english', title || ' ' || description));

-- ============================================
-- PROPERTY PHOTOS TABLE
-- ============================================

CREATE TABLE property_photos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    url VARCHAR(500) NOT NULL,
    cloudinary_id VARCHAR(255),
    is_primary BOOLEAN DEFAULT FALSE,
    display_order SMALLINT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_property_photos_property ON property_photos(property_id);
CREATE INDEX idx_property_photos_primary ON property_photos(property_id, is_primary) WHERE is_primary = TRUE;

-- ============================================
-- SUBSCRIPTIONS TABLE
-- ============================================

CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan subscription_plan NOT NULL,
    starts_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    auto_renew BOOLEAN DEFAULT TRUE,
    cancelled_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_subscriptions_user ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_active ON subscriptions(user_id, is_active) WHERE is_active = TRUE;
CREATE INDEX idx_subscriptions_expiry ON subscriptions(expires_at) WHERE is_active = TRUE;

-- ============================================
-- PAYMENTS TABLE
-- ============================================

CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id),
    subscription_id UUID REFERENCES subscriptions(id),
    amount_lkr INTEGER NOT NULL,
    currency VARCHAR(3) DEFAULT 'LKR',
    status payment_status DEFAULT 'pending',
    gateway VARCHAR(50) DEFAULT 'payhere',
    gateway_transaction_id VARCHAR(255),
    gateway_order_id VARCHAR(255),
    md5_signature VARCHAR(255),
    payment_type VARCHAR(50), -- 'subscription' or 'boost'
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX idx_payments_user ON payments(user_id);
CREATE INDEX idx_payments_subscription ON payments(subscription_id);
CREATE INDEX idx_payments_gateway_order ON payments(gateway_order_id);
CREATE INDEX idx_payments_status ON payments(status);

-- ============================================
-- BOOSTS TABLE
-- ============================================

CREATE TABLE boosts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    payment_id UUID NOT NULL REFERENCES payments(id),
    duration_days SMALLINT NOT NULL,
    starts_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_boosts_property ON boosts(property_id);
CREATE INDEX idx_boosts_active ON boosts(property_id, expires_at) WHERE expires_at > NOW();

-- ============================================
-- ENQUIRIES TABLE
-- ============================================

CREATE TABLE enquiries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    status enquiry_status DEFAULT 'pending',
    contact_revealed BOOLEAN DEFAULT FALSE,
    last_message_at TIMESTAMPTZ,
    tenant_unread_count INTEGER DEFAULT 0,
    owner_unread_count INTEGER DEFAULT 1, -- First message unread for owner
    closed_reason TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, property_id)
);

CREATE INDEX idx_enquiries_tenant ON enquiries(tenant_id);
CREATE INDEX idx_enquiries_property ON enquiries(property_id);
CREATE INDEX idx_enquiries_status ON enquiries(status);

-- ============================================
-- MESSAGES TABLE
-- ============================================

CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    enquiry_id UUID NOT NULL REFERENCES enquiries(id) ON DELETE CASCADE,
    sender_id UUID NOT NULL REFERENCES users(id),
    content TEXT NOT NULL CHECK (LENGTH(content) >= 2),
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_messages_enquiry ON messages(enquiry_id);
CREATE INDEX idx_messages_sender ON messages(sender_id);
CREATE INDEX idx_messages_created ON messages(created_at DESC);

-- ============================================
-- SAVED LISTINGS TABLE
-- ============================================

CREATE TABLE saved_listings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    saved_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, property_id)
);

CREATE INDEX idx_saved_listings_user ON saved_listings(user_id);
CREATE INDEX idx_saved_listings_property ON saved_listings(property_id);

-- ============================================
-- PROPERTY VIEWS TABLE (Analytics)
-- ============================================

CREATE TABLE property_views (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    ip_address INET,
    user_agent TEXT,
    viewed_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_property_views_property ON property_views(property_id);
CREATE INDEX idx_property_views_date ON property_views(viewed_at);
CREATE INDEX idx_property_views_dedup ON property_views(property_id, ip_address, DATE(viewed_at));

-- ============================================
-- REPORTS TABLE (Fraud/Abuse)
-- ============================================

CREATE TABLE reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    reporter_id UUID REFERENCES users(id) ON DELETE SET NULL,
    reason VARCHAR(50) NOT NULL,
    description TEXT,
    status VARCHAR(20) DEFAULT 'open',
    resolved_by UUID REFERENCES users(id),
    resolved_at TIMESTAMPTZ,
    resolution_notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_reports_property ON reports(property_id);
CREATE INDEX idx_reports_status ON reports(status);

-- ============================================
-- TRIGGERS
-- ============================================

-- Auto-update timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_properties_updated_at BEFORE UPDATE ON properties
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_enquiries_updated_at BEFORE UPDATE ON enquiries
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Auto-sync location column with lat/lng
CREATE OR REPLACE FUNCTION sync_location_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.location = ST_SetSRID(ST_MakePoint(NEW.lng, NEW.lat), 4326)::geography;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sync_properties_location BEFORE INSERT OR UPDATE ON properties
    FOR EACH ROW EXECUTE FUNCTION sync_location_column();

CREATE TRIGGER sync_universities_location BEFORE INSERT OR UPDATE ON universities
    FOR EACH ROW EXECUTE FUNCTION sync_location_column();

-- ============================================
-- SEED DATA - Sri Lankan Universities
-- ============================================

INSERT INTO universities (name, short_name, city, district, lat, lng) VALUES
('University of Colombo', 'UoC', 'Colombo', 'Colombo', 6.9022, 79.8607),
('University of Peradeniya', 'UoP', 'Peradeniya', 'Kandy', 7.2571, 80.5970),
('University of Sri Jayewardenepura', 'USJ', 'Nugegoda', 'Colombo', 6.8782, 79.8888),
('University of Kelaniya', 'UoK', 'Kelaniya', 'Gampaha', 6.9552, 79.9218),
('University of Moratuwa', 'UoM', 'Moratuwa', 'Colombo', 6.7956, 79.9006),
('University of Ruhuna', 'UoR', 'Matara', 'Matara', 5.9549, 80.5550),
('Eastern University', 'EUSL', 'Batticaloa', 'Batticaloa', 7.7170, 81.6933),
('South Eastern University', 'SEUSL', 'Oluvil', 'Ampara', 7.3158, 81.8597),
('Rajarata University', 'RUoSL', 'Mihintale', 'Anuradhapura', 8.3634, 80.4951),
('Sabaragamuwa University', 'SUSL', 'Belihuloya', 'Ratnapura', 6.7209, 80.7731),
('Wayamba University', 'WUSL', 'Kuliyapitiya', 'Kurunegala', 7.4708, 80.0398),
('Uva Wellassa University', 'UWU', 'Badulla', 'Badulla', 6.9875, 81.0548),
('SLIIT', 'SLIIT', 'Malabe', 'Colombo', 6.9147, 79.9729),
('NSBM Green University', 'NSBM', 'Homagama', 'Colombo', 6.8108, 80.0031),
('IIT Sri Lanka', 'IIT', 'Colombo', 'Colombo', 6.9093, 79.8504);

-- ============================================
-- VIEWS
-- ============================================

-- Active properties with boost status
CREATE VIEW active_properties_view AS
SELECT 
    p.*,
    CASE WHEN b.id IS NOT NULL THEN TRUE ELSE FALSE END AS is_boosted,
    b.expires_at AS boost_expires_at,
    ARRAY_AGG(ph.url ORDER BY ph.display_order) AS photo_urls
FROM properties p
LEFT JOIN boosts b ON b.property_id = p.id AND b.expires_at > NOW()
LEFT JOIN property_photos ph ON ph.property_id = p.id
WHERE p.status = 'active'
GROUP BY p.id, b.id, b.expires_at;

-- Owner subscription status
CREATE VIEW owner_subscription_status AS
SELECT 
    u.id AS user_id,
    u.name,
    u.email,
    s.plan,
    s.expires_at,
    s.is_active,
    COUNT(p.id) AS active_listings_count,
    CASE 
        WHEN s.plan = 'free' THEN 1
        WHEN s.plan = 'standard' THEN 3
        WHEN s.plan = 'premium' THEN 999999
        ELSE 0
    END AS listing_limit
FROM users u
LEFT JOIN subscriptions s ON s.user_id = u.id AND s.is_active = TRUE
LEFT JOIN properties p ON p.owner_id = u.id AND p.status = 'active'
WHERE u.role = 'owner'
GROUP BY u.id, s.plan, s.expires_at, s.is_active;

-- ============================================
-- HELPER FUNCTIONS
-- ============================================

-- Calculate distance label
CREATE OR REPLACE FUNCTION distance_label(distance_metres NUMERIC)
RETURNS TEXT AS $$
BEGIN
    RETURN CASE
        WHEN distance_metres < 500 THEN 'Under 5 min walk'
        WHEN distance_metres < 1500 THEN 
            CONCAT(ROUND(distance_metres/80), ' min walk')
        ELSE 
            CONCAT(ROUND(distance_metres/1000, 1), ' km away')
    END;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Check if user can add listing
CREATE OR REPLACE FUNCTION can_add_listing(p_user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    v_plan subscription_plan;
    v_active_count INTEGER;
    v_limit INTEGER;
BEGIN
    SELECT s.plan INTO v_plan
    FROM subscriptions s
    WHERE s.user_id = p_user_id AND s.is_active = TRUE
    ORDER BY s.created_at DESC
    LIMIT 1;
    
    v_plan := COALESCE(v_plan, 'free');
    
    SELECT COUNT(*) INTO v_active_count
    FROM properties
    WHERE owner_id = p_user_id AND status = 'active';
    
    v_limit := CASE 
        WHEN v_plan = 'free' THEN 1
        WHEN v_plan = 'standard' THEN 3
        WHEN v_plan = 'premium' THEN 999999
    END;
    
    RETURN v_active_count < v_limit;
END;
$$ LANGUAGE plpgsql;
