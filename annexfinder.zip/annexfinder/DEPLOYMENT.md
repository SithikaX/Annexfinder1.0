# 🚀 AnnexFinder Production Deployment Guide

This guide covers deploying AnnexFinder to production with recommended platforms and configurations.

## 📋 Pre-Deployment Checklist

- [ ] Database backup strategy in place
- [ ] Environment variables documented
- [ ] SSL certificates configured
- [ ] Domain name registered
- [ ] PayHere account in production mode
- [ ] Cloudinary account set up
- [ ] Email service configured (SendGrid)
- [ ] Error monitoring set up (Sentry)
- [ ] Analytics configured (Mixpanel)

## 🗄️ Database Deployment (Railway)

### Option 1: Railway PostgreSQL

```bash
# 1. Create Railway project
railway login
railway init

# 2. Add PostgreSQL service
railway add postgresql

# 3. Enable PostGIS extension
railway connect postgresql
\c railway
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;

# 4. Run migrations
railway run psql $DATABASE_URL < database/schema.sql
railway run psql $DATABASE_URL < database/queries.sql

# 5. Get connection string
railway variables
# Copy DATABASE_URL
```

**Cost**: ~$10-20/month for small-medium traffic

### Option 2: Supabase

```bash
# 1. Create project at supabase.com
# 2. Enable PostGIS from Extensions tab
# 3. Get connection string from Settings > Database
# 4. Run migrations via SQL Editor or local psql
```

**Cost**: Free tier available, then $25/month

### Option 3: AWS RDS

```bash
# 1. Create PostgreSQL RDS instance
# 2. Configure security groups
# 3. Connect and enable PostGIS:
psql -h your-instance.rds.amazonaws.com -U postgres
CREATE EXTENSION postgis;

# 4. Run migrations
```

**Cost**: ~$15-50/month depending on instance size

## 🔧 Backend Deployment (Railway)

### Setup

```bash
cd backend

# 1. Initialize Railway
railway init

# 2. Link to existing project
railway link

# 3. Set environment variables
railway variables set JWT_SECRET=your-long-random-secret
railway variables set DB_HOST=your-db-host
railway variables set DB_NAME=railway
railway variables set DB_USER=postgres
railway variables set DB_PASSWORD=your-password
railway variables set PAYHERE_MERCHANT_ID=your-id
railway variables set PAYHERE_MERCHANT_SECRET=your-secret
railway variables set CLOUDINARY_CLOUD_NAME=your-name
railway variables set CLOUDINARY_API_KEY=your-key
railway variables set CLOUDINARY_API_SECRET=your-secret
railway variables set NODE_ENV=production

# 4. Deploy
railway up
```

### Alternative: Render

1. Create new Web Service
2. Connect GitHub repository
3. Set build command: `cd backend && npm install`
4. Set start command: `cd backend && npm start`
5. Add environment variables in dashboard
6. Deploy

**Cost**: Free tier available, then $7/month

## 🎨 Frontend Deployment (Vercel)

### Setup

```bash
cd frontend

# 1. Install Vercel CLI
npm i -g vercel

# 2. Login
vercel login

# 3. Deploy
vercel

# 4. Set environment variables
vercel env add NEXT_PUBLIC_API_URL production
# Enter your backend URL: https://your-app.railway.app

vercel env add NEXT_PUBLIC_GOOGLE_MAPS_KEY production
# Enter your Google Maps API key

vercel env add NEXT_PUBLIC_SITE_URL production
# Enter your domain: https://annexfinder.lk

# 5. Deploy to production
vercel --prod
```

### Alternative: Netlify

1. Connect GitHub repository
2. Set build command: `cd frontend && npm run build`
3. Set publish directory: `frontend/.next`
4. Add environment variables
5. Deploy

**Cost**: Free tier generous, then $19/month

## 🔄 Scheduled Jobs (Cron)

### Option 1: Railway Cron Jobs

```yaml
# railway.toml
[[schedules]]
schedule = "0 1 * * *"  # Daily at 1 AM
command = "node scripts/expire-subscriptions.js"

[[schedules]]
schedule = "0 * * * *"  # Hourly
command = "node scripts/remove-expired-boosts.js"

[[schedules]]
schedule = "0 2 * * *"  # Daily at 2 AM
command = "node scripts/deduplicate-views.js"
```

### Option 2: GitHub Actions

```yaml
# .github/workflows/cron.yml
name: Scheduled Tasks
on:
  schedule:
    - cron: '0 1 * * *'  # Daily at 1 AM UTC

jobs:
  expire-subscriptions:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Run task
        run: |
          curl -X POST https://your-api.railway.app/api/admin/cron/expire-subscriptions \
            -H "Authorization: Bearer ${{ secrets.CRON_SECRET }}"
```

### Option 3: EasyCron

1. Sign up at easycron.com
2. Create cron job pointing to your API endpoint
3. Set schedule (daily/hourly)
4. Add authentication header

## 🌐 Domain Configuration

### DNS Setup

```
# Add these DNS records:

Type    Name    Value                           TTL
A       @       76.76.21.21 (Vercel IP)        3600
CNAME   www     cname.vercel-dns.com           3600
CNAME   api     your-app.railway.app           3600
```

### SSL Certificate

Both Vercel and Railway provide automatic SSL certificates via Let's Encrypt.

## 📧 Email Configuration (SendGrid)

```bash
# 1. Create SendGrid account
# 2. Verify sender domain (annexfinder.lk)
# 3. Create API key with Mail Send permission
# 4. Add to backend environment:

railway variables set SENDGRID_API_KEY=SG.xxxx
railway variables set FROM_EMAIL=no-reply@annexfinder.lk
```

### Email Templates

Create these templates in SendGrid:
- `new-enquiry` - Sent to owner
- `owner-replied` - Sent to tenant
- `listing-approved` - Sent to owner
- `listing-rejected` - Sent to owner
- `subscription-expiring` - 7 days before expiry

## 💳 PayHere Production Setup

```bash
# 1. Get production credentials from PayHere dashboard
# 2. Update environment variables:

railway variables set PAYHERE_MERCHANT_ID=your-prod-id
railway variables set PAYHERE_MERCHANT_SECRET=your-prod-secret
railway variables set PAYHERE_MODE=live

# 3. Update webhook URL in PayHere dashboard:
https://api.annexfinder.lk/api/payments/webhook

# 4. Test webhook verification in production
```

## 🖼️ Cloudinary Configuration

```bash
# 1. Create Cloudinary account
# 2. Set upload preset for unsigned uploads
# 3. Configure transformation for property images:
   - Max width: 1200px
   - Quality: 80
   - Format: auto (WebP when supported)
# 4. Add credentials to backend
```

## 📊 Monitoring & Analytics

### Error Tracking (Sentry)

```bash
npm install @sentry/node @sentry/nextjs

# Backend
railway variables set SENTRY_DSN=your-backend-dsn

# Frontend
vercel env add NEXT_PUBLIC_SENTRY_DSN production
```

### Analytics (Mixpanel)

```bash
# Frontend
vercel env add NEXT_PUBLIC_MIXPANEL_TOKEN production

# Track key events:
- Search performed
- Property viewed
- Enquiry sent
- Listing created
- Subscription purchased
```

### Uptime Monitoring

Use UptimeRobot or Better Uptime to monitor:
- Frontend: https://annexfinder.lk
- Backend: https://api.annexfinder.lk/health
- Database connectivity

## 🔒 Security Checklist

- [ ] Environment variables never committed to Git
- [ ] JWT_SECRET is long and random (64+ characters)
- [ ] CORS configured with specific origins
- [ ] Rate limiting enabled on API
- [ ] SQL injection prevention (parameterized queries ✅)
- [ ] PayHere webhook signature verification ✅
- [ ] HTTPS enforced on all domains
- [ ] Database backups automated
- [ ] User password hashing with bcrypt ✅
- [ ] Admin panel protected with authentication ✅

## 📈 Performance Optimization

### Database Indexes

Already created in schema.sql:
- ✅ GIST spatial index on properties.location
- ✅ Partial index for active listings
- ✅ Composite indexes on common queries

### Frontend Optimization

```javascript
// next.config.js
module.exports = {
  images: {
    domains: ['res.cloudinary.com'],
    formats: ['image/webp', 'image/avif'],
  },
  compress: true,
  swcMinify: true,
}
```

### CDN Configuration

Enable Vercel Edge Network for global low-latency delivery.

## 🔄 CI/CD Pipeline

### GitHub Actions

```yaml
# .github/workflows/deploy.yml
name: Deploy
on:
  push:
    branches: [main]

jobs:
  backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - run: cd backend && npm install
      - run: cd backend && npm test
      - uses: railway/cli@v1
        with:
          command: up
        env:
          RAILWAY_TOKEN: ${{ secrets.RAILWAY_TOKEN }}

  frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - run: cd frontend && npm install
      - run: cd frontend && npm run build
      - uses: vercel/action@v1
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
```

## 📞 Post-Deployment

### 1. Test Core Flows

- [ ] User registration
- [ ] Property search (university + workplace)
- [ ] Listing creation
- [ ] Enquiry messaging
- [ ] PayHere payment (use test mode first)
- [ ] Admin approval workflow

### 2. Load Testing

```bash
# Install k6
brew install k6

# Run load test
k6 run scripts/load-test.js
```

### 3. Set Up Monitoring Alerts

- Database CPU > 80%
- API response time > 2s
- Error rate > 1%
- Webhook failures

### 4. Documentation

- [ ] API documentation (Postman/Swagger)
- [ ] Owner onboarding guide
- [ ] Admin manual
- [ ] Support email templates

## 💰 Cost Estimation

**Small Scale** (100 listings, 1000 users/month):
- Database (Railway): $10/mo
- Backend (Railway): $7/mo
- Frontend (Vercel): Free
- Images (Cloudinary): $10/mo
- Email (SendGrid): Free (100 emails/day)
- **Total: ~$30/month**

**Medium Scale** (1000 listings, 10000 users/month):
- Database (Railway): $20/mo
- Backend (Railway): $19/mo
- Frontend (Vercel): $20/mo
- Images (Cloudinary): $25/mo
- Email (SendGrid): $20/mo
- **Total: ~$105/month**

**Large Scale** (10000+ listings):
- Consider AWS/GCP for better pricing
- Implement caching (Redis)
- CDN for images
- Dedicated database instance

## 🆘 Troubleshooting

### Database Connection Issues

```bash
# Test connection
psql $DATABASE_URL

# Check PostGIS
SELECT PostGIS_Version();

# Verify indexes
\di
```

### PayHere Webhook Not Firing

1. Check webhook URL in PayHere dashboard
2. Verify SSL certificate
3. Check webhook logs in PayHere
4. Test signature verification locally

### High Response Times

1. Check database query performance
2. Enable database connection pooling
3. Add Redis caching for search results
4. Optimize spatial queries

## 📚 Additional Resources

- Railway Docs: https://docs.railway.app
- Vercel Docs: https://vercel.com/docs
- PostGIS Tutorial: https://postgis.net/workshops
- PayHere API: https://support.payhere.lk

---

**Need help?** Open an issue on GitHub or email support@annexfinder.lk
